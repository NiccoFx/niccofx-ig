from common import *
C = [(104.0,104.6,103.7,104.4),(104.4,105.3,104.2,105.1),(105.1,105.9,104.9,105.7),(105.7,106.2,105.2,105.4),(105.4,105.6,104.5,104.7),
     (104.7,105.0,103.7,103.9),(103.9,104.1,102.9,103.1),(103.1,103.3,101.8,102.2),(102.2,103.2,102.0,103.0),(103.0,104.0,102.8,103.8),
     (103.8,104.9,103.6,104.7),(104.7,105.8,104.5,105.6),(105.6,106.1,105.1,105.3),(105.3,105.5,104.4,104.6)]
NS, PMIN, PMAX = 19, 99.6, 108.8
BINS = [(100.5,0.4),(101.0,0.7),(101.5,1.0),(102.0,1.6),(102.5,2.2),(103.0,2.8),(103.5,3.4),(104.0,4.0),(104.5,3.3),(105.0,2.6),(105.5,2.0),(106.0,1.5),(106.5,0.9),(107.0,0.6),(107.5,0.3)]
EV = dict(end="follow", zone=("zone",0), value0=("value",0), high=("high",0), low=("low",0), opens="opens", rotate="rotate", watch="watch",
          tags="tags", rejects="rejects", drops="drops", bounces="bounces", sell="sell", buy="buy", breaks="breaks", over="over", edges1=("edges",1))
APPEAR = [(0,3,None),(3,4,"tags"),(4,8,"rejects","bounces"),(8,12,"bounces+0.3","sell"),(12,14,"sell+0.2","buy+0.4")]
UNDER = [dict(k="box", i0=-0.4, i1=14.2, p0=102.0, p1=106.0, col=GOLD, fill=0.08, line=False, a="value0", b="end")]
ITEMS = [
 dict(k="vp", i=14.4, bins=BINS, poc=104.0, va=(102.0, 106.0), a="zone", b="end"),
 dict(k="hline", i0=-0.4, i1=14.2, p=106.0, col=RED, a="high", b="end"),
 dict(k="label", i=1.2, p=106.7, text="VAH", col=RED, size=26, a="high", b="end"),
 dict(k="hline", i0=-0.4, i1=14.2, p=102.0, col=GREEN, a="low", b="end"),
 dict(k="label", i=1.2, p=101.3, text="VAL", col=GREEN, size=26, a="low", b="end"),
 dict(k="label", i=16.4, p=108.2, text="70% of volume", col=GOLD, size=22, a="zone", b="end"),
 dict(k="ring", i=3, p=106.2, r=20, col=RED, a="tags", b="end"),
 dict(k="label", i=5.4, p=106.9, text="reject", col=RED, a="rejects", b="end"),
 dict(k="ring", i=7, p=101.8, r=20, col=GREEN, a="bounces", b="end"),
 dict(k="label", i=9.4, p=101.1, text="bounce", col=GREEN, a="bounces", b="sell"),
 dict(k="label", i=12.0, p=106.9, text="sell", col=RED, a="sell", b="end"),
 dict(k="label", i=7.0, p=100.8, text="buy", col=GREEN, a="buy", b="end"),
 dict(k="label", i=7.0, p=108.0, text="breakout + hold = range over", col=INK, a="breaks", b="edges1"),
]
HEAD = [(0,[("70% of volume ",GOLD),("trades here.",INK)]),
        ("value0-0.1",[("the ",INK),("value area.",GOLD)]),
        ("high-0.4",[("VAH ",RED),("on top.",INK)]),
        ("low-0.4",[("VAL ",GREEN),("at the bottom.",INK)]),
        ("opens-0.4",[("inside? ",INK),("expect rotation.",GOLD)]),
        ("watch-0.1",[("tag. ",INK),("reject. ",RED),("rotate.",GOLD)]),
        ("sell-0.1",[("sell VAH. ",RED),("buy VAL.",GREEN)]),
        ("breaks-0.3",[("breakout? ",INK),("range over.",RED)]),
        ("edges1-0.1",[("trade the ",INK),("edges.",GOLD)]),
        ("end-0.1",[])]
KEY = {"value":GOLD,"area":GOLD,"high":RED,"low":GREEN,"rotate":GOLD,"tags":RED,"rejects":RED,"drops":RED,"bounces":GREEN,"sell":RED,
       "buy":GREEN,"breaks":INK,"over":RED,"edges":GOLD,"volume":GOLD}
CAM = [(0.06,0.7,1.1,None,104.2),("watch-0.3",0.6,1.15,6.5,104.0),("breaks-0.3",0.6,1.0,None,None)]
SFX = [("whoosh","zone"),("pop","high"),("pop","low"),("pop","tags"),("impact","rejects"),("ding","bounces"),("pop","sell"),("pop","buy")]
END = dict(l1="trade the edges,", c1=INK, l2="not the middle.", c2=GOLD, sub="save this for your next chart")
