#!/usr/bin/env python3
import json, sys, math, subprocess, re, os
from PIL import Image, ImageDraw, ImageFont

FONTS = os.environ.get("FONTS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts"))
POP_B = os.path.join(FONTS, "Poppins-Bold.ttf")
POP_M = os.path.join(FONTS, "Poppins-Medium.ttf")
ANT = os.path.join(FONTS, "Anton.woff")
if os.path.exists(os.path.join(FONTS, "Inter-800.woff")):  # v3 fonts (Oct 27 2026): Inter Display + Anton
    POP_B = os.path.join(FONTS, "Inter-800.woff"); POP_M = os.path.join(FONTS, "Inter-600.woff")
W, H, FPS, SS = 1080, 1920, 30, 2
DARK = os.environ.get("THEME") == "dark"
if DARK:
    BG = (9, 11, 16); INK = (236, 238, 243); GREEN = (46, 204, 113); RED = (239, 68, 68)
    GOLD = (240, 180, 41); MUTED = (128, 134, 148); WICK = (120, 124, 136); LABEL_BG = (20, 23, 31)
else:
    BG = (201, 201, 201); INK = (28, 28, 30); GREEN = (24, 178, 84); RED = (222, 52, 52)
    GOLD = (196, 134, 0); MUTED = (96, 96, 100); WICK = (58, 58, 62); LABEL_BG = (248, 248, 246)

_fc = {}
def font(p, s):
    k = (p, int(s * SS))
    if k not in _fc: _fc[k] = ImageFont.truetype(p, int(s * SS))
    return _fc[k]
def ease(x):
    x = max(0.0, min(1.0, x)); return 1 - (1 - x) ** 3
def eio(x):
    x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)
def fade(t, t0, d=0.3): return ease((t - t0) / d)
def sc(v):
    if isinstance(v, tuple): return (v[0] * SS, v[1] * SS)
    return [a * SS for a in v]
def rgba(c, a): return (c[0], c[1], c[2], int(255 * max(0, min(1, a))))

C=[]
N=0
NS=26
CX0, CX1, CY0, CY1 = 50, 1030, 560, 1360
PMIN, PMAX = 98.6, 112.6
def STEP(): return (CX1 - CX0) / NS
def X(i): return CX0 + i * STEP() + STEP() / 2
def Y(p): return CY1 - (p - PMIN) / (PMAX - PMIN) * (CY1 - CY0)

# ---------------- words ----------------
def norm(w): return re.sub(r"[^a-z0-9']", "", w.lower())
# ---------------- primitives ----------------
def make_bg():
    if DARK:
        im = Image.new("RGB", (W // 4, H // 4), BG); px = im.load()
        for y in range(H // 4):
            for x in range(W // 4):
                dd = math.hypot((x - W / 8) / (W / 4), (y - H / 8 * 0.9) / (H / 4))
                k = max(0, 1 - dd * 1.5)
                px[x, y] = (int(9 + 10 * k), int(11 + 12 * k), int(16 + 18 * k))
        return im.resize((W * SS, H * SS), Image.BILINEAR)
    im = Image.new("RGB", (W * SS, H * SS), BG)
    # soft radial light in the middle
    ov = Image.new("L", (W // 4, H // 4), 0)
    px = ov.load()
    cx, cy = W / 8, H / 8 * 0.95
    for y in range(H // 4):
        for x in range(W // 4):
            dd = math.hypot((x - cx) / (W / 4), (y - cy) / (H / 4))
            px[x, y] = int(max(0, 1 - dd * 1.6) * 255)
    ov = ov.resize((W * SS, H * SS), Image.BILINEAR)
    light = Image.new("RGB", im.size, (214, 214, 214))
    im = Image.composite(light, im, ov)
    return im

def candle(d, i, prog=1.0, override=None):
    o, h, l, c = override if override else C[i]
    p = ease(prog)
    cc = o + (c - o) * p
    hh = max(o, cc) + (h - max(o, c)) * p if not override else h
    ll = min(o, cc) - (min(o, c) - l) * p if not override else l
    x = X(i); bw = STEP() * 0.58
    col = GREEN if cc >= o else RED
    d.line(sc([x, Y(hh), x, Y(ll)]), fill=WICK, width=int(3 * SS))
    top, bot = Y(max(o, cc)), Y(min(o, cc))
    if bot - top < 3: bot = top + 3
    d.rounded_rectangle(sc([x - bw / 2, top, x + bw / 2, bot]), radius=4 * SS, fill=col)

def dashed(d, x0, y, x1, col, a, w=3, dash=14, gap=10):
    x = x0
    while x < x1:
        d.line(sc([x, y, min(x + dash, x1), y]), fill=rgba(col, a), width=int(w * SS)); x += dash + gap

def label(d, x, y, s, col, a, size=26, anchor="mm", bg=True):
    if a <= 0: return
    f = font(POP_B, size)
    if bg:
        bb = d.textbbox(sc((x, y)), s, font=f, anchor=anchor)
        pad = 12 * SS
        d.rounded_rectangle([bb[0] - pad, bb[1] - pad * 0.6, bb[2] + pad, bb[3] + pad * 0.6], radius=12 * SS,
                            fill=rgba(LABEL_BG, 0.92 * a), outline=rgba(col, a), width=int(2.5 * SS))
    d.text(sc((x, y)), s, font=f, fill=rgba(col, a), anchor=anchor)

def ring(d, x, y, r, col, a, w=3):
    d.ellipse(sc([x - r, y - r, x + r, y + r]), outline=rgba(col, a), width=int(w * SS))

def arrow(d, x0, y0, x1, y1, col, a, w=4, L=18):
    d.line(sc([x0, y0, x1, y1]), fill=rgba(col, a), width=int(w * SS))
    ang = math.atan2(y1 - y0, x1 - x0)
    for s in (-1, 1):
        d.line(sc([x1, y1, x1 - L * math.cos(ang + s * 0.5), y1 - L * math.sin(ang + s * 0.5)]), fill=rgba(col, a), width=int(w * SS))

def check(d, x, y, s, col, a, w=6):
    d.line(sc([x - s, y, x - s * 0.3, y + s * 0.7, x + s, y - s * 0.8]), fill=rgba(col, a), width=int(w * SS), joint="curve")

# ---------------- UI (screen space) ----------------
def draw_head(d, t, ev):
    hs = headlines(ev)
    cur, nxt = None, None
    for k, (t0, segs) in enumerate(hs):
        if t >= t0: cur = (t0, segs, hs[k + 1][0] if k + 1 < len(hs) else 999)
    if not cur or not cur[1]: return
    t0, segs, t1 = cur
    a = fade(t, t0, 0.25) * (1 - fade(t, t1 - 0.15, 0.15))
    rise = 16 * (1 - ease((t - t0) / 0.3))
    f = font(POP_B, 66)
    total = sum(d.textlength(s, font=f) for s, _ in segs) / SS
    x = W / 2 - total / 2
    for s, col in segs:
        d.text(sc((x, 330 + rise)), s, font=f, fill=rgba(col, a), anchor="lm")
        x += d.textlength(s, font=f) / SS

KEY = {}

def chunks(words):
    out, cur = [], []
    for w in words:
        cur.append(w)
        if len(cur) >= 5 or re.search(r"[.?!,]$", w[0]):
            out.append(cur); cur = []
    if cur: out.append(cur)
    return out

def draw_caption(d, t, chs, end_t):
    cur = None
    for k, ch in enumerate(chs):
        nxt = chs[k + 1][0][1] if k + 1 < len(chs) else end_t
        if ch[0][1] - 0.08 <= t < nxt - 0.02: cur = ch
    if not cur: return
    f = font(POP_B, 48)
    words = [w[0] for w in cur]
    sp = d.textlength(" ", font=f) / SS
    widths = [d.textlength(w, font=f) / SS for w in words]
    total = sum(widths) + sp * (len(words) - 1)
    x = W / 2 - total / 2
    ca = fade(t, cur[0][1] - 0.08, 0.12)
    for (w, st, en), ww in zip(cur, widths):
        if t >= st:
            nx = [q for q in cur if q[1] > st]
            active = t < (nx[0][1] if nx else st + 0.6)
            col = KEY.get(norm(w), INK) if not active else (KEY.get(norm(w), GOLD) if norm(w) in KEY else GOLD)
            col = col if active or norm(w) in KEY else INK
            a = 1.0
        else:
            col, a = INK, 0.35
        d.text(sc((x, 1545)), w, font=f, fill=rgba(col, a * ca), anchor="lm")
        x += ww + sp

def frame(t, bg, ev, chs, end_t):
    im = world(t, bg, ev)
    s, cx, cy = camera(t, ev)
    if s > 1.001:
        Wd, Hd = im.size
        cw, ch = Wd / s, Hd / s
        px, py = cx * SS, cy * SS
        px = min(max(px, cw / 2), Wd - cw / 2); py = min(max(py, ch / 2), Hd - ch / 2)
        im = im.resize((Wd, Hd), Image.BILINEAR, box=(px - cw / 2, py - ch / 2, px + cw / 2, py + ch / 2))
    d = ImageDraw.Draw(im, "RGBA")
    draw_ui(d, t, ev, chs, end_t)
    return im.resize((W, H), Image.LANCZOS)

G = {}
def _init(p):
    words = fix_words(json.load(open(p)))
    G["ev"] = schedule(words); G["chs"] = chunks(words)
    G["end_t"] = words[-1][2] + 1.8; G["bg"] = make_bg()
def _render(k): return frame(k / FPS, G["bg"], G["ev"], G["chs"], G["end_t"]).tobytes()

def main():
    _init(sys.argv[1]); out = sys.argv[2]
    if "--preview" in sys.argv:
        ts = [float(x) for x in sys.argv[sys.argv.index("--preview") + 1].split(",")]
        for k, tt in enumerate(ts):
            frame(tt, G["bg"], G["ev"], G["chs"], G["end_t"]).save(out.replace(".mp4", f"_p{k}.png"))
        print(json.dumps({k: round(v, 2) for k, v in G["ev"].items() if k != "ct"}))
        return
    nfr = int(G["end_t"] * FPS)
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    from multiprocessing import Pool
    with Pool(os.cpu_count(), initializer=_init, initargs=(sys.argv[1],)) as pool:
        for b in pool.imap(_render, range(nfr), chunksize=6): p.stdin.write(b)
    p.stdin.close(); p.wait(); print("done", out, nfr / FPS)

if __name__ == "__main__":
    main()
