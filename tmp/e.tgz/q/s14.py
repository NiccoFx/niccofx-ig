from common import *
C = [(100.6,102.0,100.3,101.7),(101.7,103.0,101.4,102.7),(102.7,103.2,101.9,102.2),(102.2,104.0,102.0,103.7),(103.7,105.6,103.4,105.3),
     (105.3,107.0,105.0,106.7),(106.7,107.6,106.2,107.3),(107.3,107.5,106.0,106.3),(106.3,106.6,104.9,105.2),(105.2,105.5,103.6,103.9),
     (103.9,104.3,102.8,103.2),(103.2,104.6,103.0,104.4),(104.4,104.8,103.9,104.2),(104.2,105.9,104.0,105.6),
     (105.6,105.8,104.6,104.8),(104.8,105.0,103.5,103.9),(103.9,105.7,103.7,105.5),(105.5,107.4,105.3,107.1),(107.1,108.9,106.8,108.6),
     (108.6,110.6,108.3,110.3),(110.3,111.0,109.6,110.8)]
NS, PMIN, PMAX = 23, 99.6, 112.6
EV = dict(CD, buying="buying", where="where's", ans="after:n1", reason="reason", look="look", everyone=("everyone",0), dips="dips",
          takes="takes", goes="goes", you=("you",0), sits1=("sits",1), swing="swing", structure="structure", tight="tight",
          smart="smart", so=("so",0))
APPEAR = [(0,14,None),(14,16,"dips","takes+0.3"),(16,21,"goes","you+0.5")]
RING = (18.5, 108.6)
ITEMS = [
 dict(k="hline", i0=12.6, i1=21.0, p=105.6, col=INK, text="entry", a=0.1, b="tight-0.3"),
 dict(k="ring", i=13, p=105.6, r=24, col=GOLD, a=0, b="look"),
 dict(k="label", i=13, p=107.0, text="buy here", col=GOLD, a=0, b="look"),
 dict(k="hline", i0=12.4, i1=21.0, p=103.8, col=INK, a="where", b="tight-0.3"),
 dict(k="hline", i0=9.4, i1=21.0, p=102.4, col=INK, a="where+0.2", b="tight-0.3"),
 dict(k="label", i=21.7, p=103.8, text="A", col=INK, size=28, a="where", b="ans"),
 dict(k="label", i=21.7, p=102.4, text="B", col=INK, size=28, a="where+0.2", b="ans"),
 dict(k="label", i=21.7, p=103.8, text="A", col=RED, size=28, a="ans", b="tight-0.3"),
 dict(k="label", i=21.7, p=102.4, text="B", col=GREEN, size=28, a="ans", b="tight-0.3"),
 dict(k="dots", i0=12.6, i1=15.8, p0=103.6, p1=104.0, n=8, col=GOLD, a="everyone", b="takes+0.1"),
 dict(k="label", i=17.2, p=104.5, text="everyone's stops", col=RED, a="everyone", b="dips"),
 dict(k="ring", i=15, p=103.5, r=22, col=RED, a="takes", b="sits1"),
 dict(k="label", i=17.4, p=103.1, text="stopped out", col=RED, a="takes", b="sits1"),
 dict(k="arrow", i0=16, p0=106.0, i1=19.8, p1=111.6, col=GREEN, a="goes", b="sits1"),
 dict(k="label", i=16.6, p=110.4, text="without you", col=GREEN, a="you", b="sits1"),
 dict(k="ring", i=10, p=102.8, r=22, col=GREEN, a="swing", b="tight-0.3"),
 dict(k="label", i=7.0, p=101.6, text="swing low", col=GREEN, a="swing", b="tight-0.3"),
 dict(k="label", i=16.0, p=101.4, text="must break structure", col=GREEN, a="structure", b="tight-0.3"),
]
CMP = dict(a="tight", b="so", cards=[
 dict(title="TIGHT", col=RED, t="tight", level=1090,
      seq=[(1000,990,1060,1050),(1050,950,1070,965),(965,955,1110,1080),(1080,900,1095,915),(915,800,925,815)],
      mark="x", l1="gets", l2="hunted"),
 dict(title="SMART", col=GREEN, t="smart", level=1160,
      seq=[(1000,990,1060,1050),(1050,950,1070,965),(965,955,1110,1080),(1080,900,1095,915),(915,800,925,815)],
      mark="check", l1="gets", l2="respected")])
HEAD = [(0,[("you're ",INK),("buying here.",GOLD)]),
        ("where-0.1",[("stop at ",INK),("A or B?",GOLD)]),
        ("ans-0.05",[("B.",GREEN)]),
        ("reason-0.1",[("it's the ",INK),("liquidity.",GOLD)]),
        ("everyone-0.5",[("where ",INK),("everyone's",RED),(" stop is.",INK)]),
        ("takes-0.2",[("stops ",INK),("hunted.",RED)]),
        ("sits1-0.1",[("below the ",INK),("swing low.",GREEN)]),
        ("tight-0.1",[("tight ",RED),("vs ",INK),("smart.",GREEN)]),
        ("so-0.1",[("stop where ",INK),("you're wrong.",GOLD)]),
        ("end-0.1",[])]
KEY = {"buying":GOLD,"liquidity":GOLD,"everyone":RED,"dips":RED,"takes":RED,"hunted":RED,"smart":GREEN,"respected":GREEN,
       "structure":GREEN,"swing":GREEN,"wrong":GOLD,"b":GREEN,"tight":RED}
CAM = [(0.06,0.7,1.15,13.0,105.5),("look-0.3",0.7,1.3,13.5,104.6),("sits1-0.3",0.6,1.12,12.0,105.0),("tight-0.4",0.5,1.0,None,None)]
SFX = [("pop","everyone"),("impact","takes"),("whoosh","goes"),("pop","swing"),("pop","structure")]
END = dict(l1="put your stop", c1=INK, l2="where you're wrong.", c2=GOLD, sub="save this before your next trade")
