from common import *
C = [(101.6,102.0,100.8,101.2),(101.2,102.6,100.9,102.4),(102.4,103.9,102.1,103.6),(103.6,105.0,103.2,104.7),(104.7,104.9,103.5,103.8),
     (103.8,104.2,102.9,103.3),(103.3,105.2,103.1,104.9),(104.9,106.9,104.6,106.6),(106.6,108.0,106.2,107.7),(107.7,107.9,106.4,106.7),
     (106.7,107.0,105.7,106.0),(106.0,107.8,105.8,107.5),(107.5,109.4,107.2,109.1),(109.1,110.6,108.8,110.3),(110.3,110.5,109.0,109.3),
     (109.3,109.6,108.1,108.4),(108.4,108.9,107.8,108.6),(108.6,110.2,108.4,110.0),(110.0,111.6,109.8,111.3),(111.3,112.6,111.0,112.3),
     (112.3,112.5,111.0,111.2),(111.2,111.4,109.6,109.9),(109.9,110.0,107.4,107.6),(107.6,108.3,106.6,106.9),(106.9,107.6,105.6,105.9)]
NS, PMIN, PMAX = 27, 99.2, 114.4
EV = dict(CD, trend=("trend",0), dropped="dropped", ans=("not",0), reason="reason", look="look", higher=("higher",0),
          stays="stays", holds=("holds",0), breaks1=("breaks",1), structure="structure", cont="continues", watch="watch",
          breaks2=("breaks",2), made="made", character=("character",0), character1=("character",1), shifting="shifting", pull="pullback", so=("so",0))
APPEAR = [(0,16,None),(16,17,"holds"),(17,19,"breaks1","structure"),(19,20,"continues"),(20,23,"watch","breaks2+0.3"),(23,25,"made","character")]
RING = (21.5, 106.0)
ITEMS = [
 dict(k="label", i=5, p=102.1, text="HL", col=GREEN, size=22, a="higher", b="watch"),
 dict(k="label", i=8, p=108.8, text="HH", col=GREEN, size=22, a="higher+0.15", b="watch"),
 dict(k="label", i=10, p=104.9, text="HL", col=GREEN, size=22, a="higher+0.3", b="watch"),
 dict(k="label", i=13, p=111.4, text="HH", col=GREEN, size=22, a="higher+0.45", b="watch"),
 dict(k="hline", i0=9.6, i1=17.0, p=105.7, col=INK, text="last low", a="stays", b="breaks1"),
 dict(k="ring", i=16, p=107.8, r=22, col=GREEN, a="holds", b="structure+0.8"),
 dict(k="label", i=16, p=106.8, text="holds", col=GREEN, a="holds", b="structure+0.8"),
 dict(k="hline", i0=12.6, i1=19.6, p=110.6, col=GREEN, a="breaks1", b="watch"),
 dict(k="label", i=15.6, p=111.5, text="BOS", col=GREEN, a="structure", b="watch"),
 dict(k="arrow", i0=17, p0=109.0, i1=20.2, p1=113.6, col=GREEN, a="continues", b="watch"),
 dict(k="hline", i0=15.6, i1=23.6, p=107.8, col=INK, text="this low", a="watch", b="pull-0.3"),
 dict(k="arrow", i0=16.3, p0=108.4, i1=18.8, p1=112.3, col=GOLD, a="made", b="character+0.6"),
 dict(k="ring", i=22, p=107.6, r=22, col=RED, a="breaks2", b="pull-0.3"),
 dict(k="label", i=24.4, p=109.0, text="CHoCH", col=RED, size=28, a="character", b="pull-0.3"),
 dict(k="arrow", i0=21, p0=111.6, i1=24.8, p1=104.6, col=RED, a="shifting", b="pull-0.3"),
]
CMP = dict(a="pull", b="so", cards=[
 dict(title="PULLBACK", col=GREEN, t="pull", tsize=46, level=1025,
      seq=[(1010,960,1025,970),(970,860,980,875),(875,865,940,930),(930,920,995,980),(980,800,990,815),(815,720,825,735)],
      mark="check", l1="holds the low", l2="trend continues"),
 dict(title="CHoCH", col=RED, t="character1", level=1025,
      seq=[(1010,960,1025,970),(970,860,980,875),(875,865,940,930),(930,920,1010,1000),(1000,990,1090,1075),(1075,1060,1140,1125)],
      mark="x", l1="breaks the low", l2="trend shifts")])
HEAD = [(0,[("gold is in an ",INK),("uptrend.",GREEN)]),
        ("dropped-0.3",[("price just ",INK),("dropped.",RED)]),
        ("trend-0.3",[("is the trend ",INK),("over?",GOLD)]),
        ("ans-0.05",[("not yet.",GREEN)]),
        ("look-0.1",[("higher highs, ",INK),("higher lows.",GREEN)]),
        ("stays-0.1",[("the low ",INK),("holds.",GREEN)]),
        ("structure-0.3",[("break of ",INK),("structure.",GREEN)]),
        ("watch-0.1",[("now ",INK),("watch.",GOLD)]),
        ("character-0.4",[("change of ",INK),("character.",RED)]),
        ("pull-0.1",[("pullback ",GREEN),("vs ",INK),("CHoCH.",RED)]),
        ("so-0.1",[("wait for the ",INK),("low to break.",GOLD)]),
        ("end-0.1",[])]
KEY = {"uptrend":GREEN,"dropped":RED,"over":GOLD,"not":GREEN,"yet":GREEN,"holds":GREEN,"structure":GREEN,"continues":GREEN,
       "character":RED,"shifting":RED,"low":GOLD,"higher":GREEN}
CAM = [(0.06,0.7,1.25,8.0,106.0),("look-0.3",0.7,1.22,8.5,106.4),("breaks1-0.3",0.7,1.3,16.5,109.6),("watch-0.3",0.7,1.25,20.0,109.4),("pull-0.4",0.5,1.0,None,None)]
SFX = [("pop","higher"),("pop","holds"),("impact","structure"),("pop","made"),("impact","character")]
END = dict(l1="wait for the low", c1=INK, l2="to break.", c2=GOLD, sub="save this for your next trade")
