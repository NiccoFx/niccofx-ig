import sys, json, wave, re, numpy as np
src, wj, out = sys.argv[1:4]; EDU = len(sys.argv) > 4 and sys.argv[4] == "edu"
w = wave.open(src); sr = w.getframerate(); a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16); w.close()
words = json.load(open(wj))
def n(x): return re.sub(r"[^a-z0-9]", "", x.lower())
PAUSE = {} if EDU else {"decide": 0.30, "three": 0.42, "3": 0.42, "two": 0.42, "2": 0.42, "one": 0.42, "1": 0.42}
GAP = 0.6 if EDU else 0.24
done = set(); ops = []
for k, (wd, s, e) in enumerate(words[:-1]):
    ns = words[k + 1][1]; g = ns - e
    if g > GAP + 0.04:
        c0 = e + GAP / 2; c1 = ns - GAP / 2; ops.append(("cut", c0, c1))
    t = n(wd); key = {"3": "three", "2": "two", "1": "one"}.get(t, t)
    if t in PAUSE and key not in done and len(done) < 4:
        done.add(key); ops.append(("pause", (e + ns) / 2, PAUSE[t]))
ops.sort(key=lambda o: o[1])
segs = []; prev = 0; removed = 0
for o in ops:
    if o[0] == "cut":
        i0, i1 = int(o[1] * sr), int(o[2] * sr)
        if i0 < prev: continue
        segs.append(a[prev:i0]); prev = i1; removed += o[2] - o[1]
    else:
        i = max(int(o[1] * sr), prev); segs.append(a[prev:i]); segs.append(np.zeros(int(o[2] * sr), dtype=np.int16)); prev = i
segs.append(a[prev:])
o = wave.open(out, "w"); o.setnchannels(1); o.setsampwidth(2); o.setframerate(sr); o.writeframes(np.concatenate(segs).tobytes()); o.close()
print("removed", round(removed, 2), "pauses", len(done))
