from common import *
C = [(105.6,106.2,104.8,105.0),(105.0,105.3,103.8,104.1),(104.1,104.4,103.2,103.5),(103.5,104.4,103.0,104.2),(104.2,105.6,104.0,105.4),
     (105.4,105.8,104.6,104.8),(104.8,105.0,103.6,103.8),(103.8,104.6,103.0,104.4),(104.4,105.9,104.2,105.6),(105.6,106.0,104.9,105.1),
     (105.1,105.3,103.7,103.9),(103.9,104.5,103.0,104.3),(104.3,104.8,103.6,103.8),(103.8,104.0,102.9,103.1),(103.1,103.3,101.6,101.8),
     (101.8,102.1,100.6,100.9),(100.9,101.9,100.7,101.7),(101.7,102.8,101.5,102.6),(102.6,103.2,102.2,102.4),(102.4,102.6,101.0,101.2),
     (101.2,101.5,99.8,100.0),(100.0,100.3,98.8,99.1)]
NS, PMIN, PMAX = 23, 97.8, 107.6
EV = dict(end="follow", flips="flips", step0=("step",0), step1=("step",1), step2=("step",2), bounced="bounced", brk=("break",0),
          close="close", back="back", becomes="becomes", trapped="trapped", entry="entry", stop="stop", target="target", dont="don't")
APPEAR = [(0,12,None),(12,15,"step1","close+0.2"),(15,18,"step2","back+0.4"),(18,19,"becomes"),(19,22,"target","dont")]
ITEMS = [
 dict(k="hline", i0=-0.4, i1=22.4, p=103.0, col=GREEN, a="step0", b="becomes"),
 dict(k="hline", i0=-0.4, i1=22.4, p=103.0, col=RED, a="becomes", b="end"),
 dict(k="ring", i=3, p=103.0, r=20, col=GREEN, a="bounced", b="step1"),
 dict(k="ring", i=7, p=103.0, r=20, col=GREEN, a="bounced+0.15", b="step1"),
 dict(k="ring", i=11, p=103.0, r=20, col=GREEN, a="bounced+0.3", b="step1"),
 dict(k="label", i=7, p=102.2, text="3 touches", col=GREEN, a="bounced", b="step1"),
 dict(k="badge", i=14.2, p=107.0, n=1, text="find support", col=INK, a="step0", b="becomes"),
 dict(k="badge", i=14.2, p=106.1, n=2, text="break & close below", col=INK, a="step1", b="becomes"),
 dict(k="badge", i=14.2, p=105.2, n=3, text="wait for the retest", col=GOLD, a="step2", b="becomes"),
 dict(k="ring", i=14, p=101.8, r=22, col=RED, a="close", b="back"),
 dict(k="label", i=11.8, p=101.2, text="close below", col=RED, a="close", b="back"),
 dict(k="arrow", i0=16.0, p0=100.9, i1=17.9, p1=102.9, col=GOLD, a="back", b="becomes+0.4"),
 dict(k="label", i=7.0, p=103.8, text="support", col=GREEN, a="step0", b="becomes"),
 dict(k="label", i=7.0, p=103.8, text="now resistance", col=RED, a="becomes", b="end"),
 dict(k="label", i=20.4, p=104.2, text="trapped buyers sell", col=RED, a="trapped", b="entry"),
 dict(k="ring", i=18, p=102.9, r=22, col=GOLD, a="entry", b="end"),
 dict(k="label", i=20.4, p=104.2, text="sell here", col=GOLD, a="entry", b="end"),
 dict(k="hline", i0=17.5, i1=21.6, p=103.7, col=RED, a="stop", b="end"),
 dict(k="label", i=21.6, p=104.9, text="stop", col=RED, size=22, a="stop", b="end"),
 dict(k="hline", i0=15.0, i1=21.6, p=100.6, col=GREEN, a="target", b="end"),
 dict(k="label", i=13.4, p=100.0, text="target", col=GREEN, size=22, a="target", b="end"),
 dict(k="arrow", i0=18.6, p0=102.0, i1=21.3, p1=99.3, col=RED, a="target", b="end"),
]
HEAD = [(0,[("old support ",INK),("flips.",GOLD)]),
        ("step0-0.1",[("step 1: ",GOLD),("find support.",INK)]),
        ("step1-0.1",[("step 2: ",GOLD),("break & close.",INK)]),
        ("step2-0.1",[("step 3: ",GOLD),("the retest.",INK)]),
        ("becomes-0.4",[("now it's ",INK),("resistance.",RED)]),
        ("entry-0.3",[("sell ",RED),("the retest.",INK)]),
        ("dont-0.1",[("wait for ",INK),("the retest.",GOLD)]),
        ("end-0.1",[])]
KEY = {"flips":GOLD,"support":GREEN,"resistance":RED,"break":RED,"close":RED,"retest":GOLD,"trapped":RED,"entry":GOLD,"sell":RED,
       "stop":RED,"target":GREEN,"bounced":GREEN}
CAM = [(0.06,0.7,1.15,None,104.0),("step1-0.3",0.6,1.15,12.0,103.4),("back-0.3",0.6,1.15,16.5,102.8),("target-0.3",0.6,1.0,None,None)]
SFX = [("pop","step0"),("pop","bounced"),("pop","step1"),("impact","close"),("pop","step2"),("impact","becomes"),("pop","stop"),("ding","target")]
END = dict(l1="don't sell the break.", c1=INK, l2="sell the retest.", c2=GOLD, sub="save this for your next setup")
