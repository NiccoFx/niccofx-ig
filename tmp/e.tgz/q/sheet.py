import sys, glob
from PIL import Image
fs = sorted(glob.glob(sys.argv[1] + "_p*.png"), key=lambda f: int(f.split("_p")[-1][:-4]))
ims = [Image.open(f).resize((324, 576)) for f in fs]
cols = 6; rows = (len(ims) + cols - 1) // cols
S = Image.new("RGB", (324 * cols, 576 * rows), (255, 255, 255))
for i, im in enumerate(ims): S.paste(im, ((i % cols) * 324, (i // cols) * 576))
S.save(sys.argv[2])
