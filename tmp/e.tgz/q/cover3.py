# dark reel cover: python3 cover3.py frame.png out.jpg  (edit titles below per reel)
import sys
from PIL import Image, ImageDraw, ImageFont
im = Image.open(sys.argv[1]).convert("RGB"); W, H = im.size
ov = Image.new("RGBA", (W, H), (9, 11, 16, 0)); d = ImageDraw.Draw(ov)
for y in range(H): d.line([(0, y), (W, y)], fill=(9, 11, 16, 150 if 300 < y < 1450 else 60))
im = Image.alpha_composite(im.convert("RGBA"), ov)
ImageDraw.Draw(im).rectangle([0, 1480, W, 1620], fill=(12, 14, 20, 255))
A = lambda s: ImageFont.truetype("/home/user/q/fonts/Anton.woff", s)
I = lambda s: ImageFont.truetype("/home/user/q/fonts/Inter-800.woff", s)
d = ImageDraw.Draw(im)
def t(y, txt, f, col): d.text((W/2, y), txt, font=f, fill=col, anchor="mm", stroke_width=8, stroke_fill=(9, 11, 16))
t(560, "NAKED POC", A(210), (240, 180, 41)); t(760, "THE GOLD MAGNET", A(120), (236, 238, 243)); t(900, "3 rules · +2R", I(56), (46, 204, 113))
im.convert("RGB").save(sys.argv[2], quality=92)
