from common import *
C = [(106.0,106.4,104.8,105.1),(105.1,105.6,103.9,104.2),(104.2,105.4,103.8,105.0),(105.0,105.2,103.0,103.3),(103.3,103.8,101.8,102.1),
     (102.1,102.9,101.2,102.6),(102.6,102.8,100.5,101.0),(101.0,103.2,100.8,102.9),(102.9,105.0,102.6,104.7),(104.7,107.2,104.4,106.9),
     (106.9,108.6,106.5,108.3),(108.3,110.0,107.9,109.6),(109.6,109.8,108.2,108.5),(108.5,108.9,106.6,106.9),(106.9,107.3,105.0,105.3),
     (105.3,105.6,103.4,103.8),(103.8,104.6,102.9,104.3),(104.3,106.6,104.0,106.3),(106.3,108.5,106.0,108.2),(108.2,110.4,107.9,110.1),
     (110.1,112.3,109.8,112.0)]
NS, PMIN, PMAX = 22, 98.8, 114.0
EV = dict(end="follow", here="here's", step0=("step",0), step1=("step",1), step2=("step",2), brk=("break",0), fib="fibonacci",
          swing0=("swing",0), swing1=("swing",1), mark="mark", optimal="optimal", pulls="pulls", buy0=("buy",0), stop="stop",
          target="target", why="why", late="late", discount="discount", dont="don't")
APPEAR = [(0,12,None),(12,17,"pulls","buy0"),(17,21,"target","why")]
ITEMS = [
 dict(k="box", i0=11.4, i1=21.3, p0=102.5, p1=104.11, col=GOLD, fill=0.15, a=0.1, b="here+0.6"),
 dict(k="label", i=16.0, p=103.3, text="OTE?", col=GOLD, a=0.1, b="here+0.6"),
 dict(k="badge", i=0.4, p=112.9, n=1, text="break structure", col=INK, a="step0", b="why"),
 dict(k="badge", i=0.4, p=111.8, n=2, text="draw the fib", col=INK, a="step1", b="why"),
 dict(k="badge", i=0.4, p=110.7, n=3, text="62–79% zone", col=GOLD, a="step2", b="why"),
 dict(k="hline", i0=-0.4, i1=9.8, p=106.4, col=GREEN, text="BOS", bold=True, a="brk", b="why"),
 dict(k="ring", i=6, p=100.5, r=20, col=INK, a="swing0", b="mark"),
 dict(k="ring", i=11, p=110.0, r=20, col=INK, a="swing1", b="mark"),
 dict(k="arrow", i0=6, p0=100.7, i1=11, p1=109.8, col=GOLD, a="fib", b="pulls"),
 dict(k="hline", i0=6.4, i1=20.0, p=110.0, col=INK, text="0%", a="fib+0.3", b="target"),
 dict(k="hline", i0=6.4, i1=20.0, p=104.11, col=GOLD, text="62%", a="fib+0.5", b="end"),
 dict(k="hline", i0=6.4, i1=20.0, p=103.30, col=GOLD, text="70.5%", a="fib+0.6", b="end"),
 dict(k="hline", i0=6.4, i1=20.0, p=102.50, col=GOLD, text="79%", a="fib+0.7", b="end"),
 dict(k="hline", i0=6.4, i1=20.0, p=100.5, col=INK, text="100%", a="fib+0.4", b="stop"),
 dict(k="box", i0=11.4, i1=20.0, p0=102.5, p1=104.11, col=GOLD, fill=0.2, a="mark", b="end"),
 dict(k="label", i=19.4, p=103.3, text="OTE", col=GOLD, a="optimal", b="end"),
 dict(k="ring", i=16, p=103.2, r=22, col=GOLD, a="buy0", b="end"),
 dict(k="label", i=13.6, p=103.3, text="entry", col=GOLD, a="buy0", b="end"),
 dict(k="hline", i0=14.5, i1=20.0, p=100.2, col=RED, text="stop", bold=True, a="stop", b="end"),
 dict(k="hline", i0=14.5, i1=20.0, p=110.0, col=GREEN, text="target", bold=True, a="target", b="end"),
 dict(k="arrow", i0=16.6, p0=104.8, i1=20.4, p1=112.8, col=GREEN, a="target", b="end"),
 dict(k="label", i=7.0, p=108.8, text="late sellers trapped", col=RED, a="late", b="dont"),
 dict(k="label", i=12.8, p=101.5, text="filled at a discount", col=GOLD, a="discount", b="dont"),
]
HEAD = [(0,[("smart money ",INK),("buys here.",GOLD)]),
        ("here-0.1",[("the ",INK),("OTE zone.",GOLD)]),
        ("step0-0.1",[("step 1: ",GOLD),("break structure.",INK)]),
        ("step1-0.1",[("step 2: ",GOLD),("draw the fib.",INK)]),
        ("step2-0.1",[("step 3: ",GOLD),("62–79% zone.",INK)]),
        ("pulls-0.1",[("buy the ",INK),("deep pullback.",GREEN)]),
        ("stop-0.1",[("small risk. ",RED),("big target.",GREEN)]),
        ("why-0.1",[("why it ",INK),("works.",GOLD)]),
        ("dont-0.1",[("buy the pullback ",INK),("into OTE.",GOLD)]),
        ("end-0.1",[])]
KEY = {"buys":GOLD,"ote":GOLD,"structure":GREEN,"fibonacci":GOLD,"optimal":GOLD,"entry":GOLD,"stop":RED,"risk":RED,"target":GREEN,
       "trapped":RED,"discount":GOLD,"pullback":GREEN,"breakout":RED,"buy":GOLD,"swing":INK}
CAM = [("step0-0.3",0.6,1.15,8.0,106.0),("mark-0.3",0.6,1.08,None,105.2),("target-0.3",0.6,1.0,None,None)]
SFX = [("pop","step0"),("pop","step1"),("pop","step2"),("whoosh","fib"),("impact","buy0"),("pop","stop"),("ding","target")]
END = dict(l1="buy the pullback", c1=INK, l2="into OTE.", c2=GOLD, sub="save this for your next setup")
