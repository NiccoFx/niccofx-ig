s = open("q.py").read()
a = '    elif k == "badge":'
b = '''    elif k == "vp":
        h = it.get("h", 0.5); poc = it.get("poc"); va = it.get("va", (0, 0)); t0 = T(it.get("a", 0), ev)
        for j, (pp, L) in enumerate(it["bins"]):
            g = ease((t - t0 - 0.025 * j) / 0.5)
            if g <= 0: continue
            x0 = X(it["i"]); x1 = x0 + L * B.STEP() * g
            if poc is not None and abs(pp - poc) < 1e-6: c, al = GOLD, 0.95
            elif va[0] <= pp <= va[1]: c, al = GOLD, 0.45
            else: c, al = INK, 0.22
            d.rounded_rectangle(sc([x0, Y(pp + h * 0.45), max(x1, x0 + 2), Y(pp - h * 0.45)]), radius=4 * SS, fill=rgba(c, al * a))
''' + a
assert a in s and 'k == "vp"' not in s
s = s.replace(a, b, 1)
open("q.py", "w").write(s); print("ok")
