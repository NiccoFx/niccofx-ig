from common import *
C = [(102.0,103.0,101.6,102.7),(102.7,104.0,102.4,103.8),(103.8,104.6,103.5,104.4),(104.4,105.6,104.1,105.3),(105.3,105.5,104.3,104.6),
     (104.6,104.9,104.0,104.2),(104.2,106.6,104.1,106.3),(106.3,108.2,106.0,107.9),(107.9,109.0,107.4,108.6),(108.6,108.8,107.2,107.5),
     (107.5,107.7,105.9,106.2),(106.2,106.5,104.6,104.9),(104.9,105.1,102.6,102.9),(102.9,103.3,101.2,101.6),(101.6,102.8,101.3,102.5),
     (102.5,104.1,102.3,103.9),(103.9,104.8,103.5,103.7),(103.7,103.9,102.0,102.3),(102.3,102.6,100.6,100.9),(100.9,101.3,99.3,99.6),
     (99.6,99.9,98.5,98.8)]
NS, PMIN, PMAX = 22, 97.4, 110.6
EV = dict(end="follow", fails="fails", flips="flips", breaker0=("breaker",0), bullish="bullish", defend="defend", smashes="smashes",
          closes="closes", trapped="trapped", comes="comes", sell0=("sell",0), support="support", breaker1=("breaker",1),
          sell1=("sell",1), stop="stop", target="target", failed="failed")
APPEAR = [(0,9,None),(9,12,"defend","smashes"),(12,13,"smashes"),(13,14,"closes"),(14,17,"comes","sell0"),(17,21,"sell1","failed")]
ITEMS = [
 dict(k="box", i0=4.55, i1=20.6, p0=104.0, p1=104.9, col=GREEN, fill=0.16, a=0.1, b="smashes+0.4"),
 dict(k="label", i=12.6, p=105.7, text="bullish order block", col=GREEN, a="bullish", b="smashes"),
 dict(k="box", i0=4.55, i1=20.6, p0=104.0, p1=104.9, col=RED, fill=0.16, a="smashes+0.3", b="end"),
 dict(k="label", i=14.6, p=105.6, text="broken", col=RED, a="closes", b="comes"),
 dict(k="label", i=10.3, p=103.2, text="trapped buyers", col=RED, a="trapped", b="support"),
 dict(k="arrow", i0=16, p0=106.4, i1=16, p1=105.1, col=RED, a="sell0", b="sell1"),
 dict(k="label", i=18.8, p=106.0, text="exit at breakeven", col=RED, a="sell0", b="support"),
 dict(k="label", i=18.6, p=106.0, text="now resistance", col=RED, a="support", b="sell1"),
 dict(k="label", i=19.0, p=104.45, text="breaker", col=RED, a="breaker1", b="end"),
 dict(k="ring", i=16, p=104.6, r=22, col=GOLD, a="sell1", b="end"),
 dict(k="label", i=14.2, p=105.6, text="sell here", col=GOLD, a="sell1", b="end"),
 dict(k="hline", i0=15.4, i1=20.0, p=105.3, col=RED, text="stop", bold=True, a="stop", b="end"),
 dict(k="hline", i0=12.6, i1=20.0, p=101.2, col=GREEN, text="target", bold=True, a="target", b="end"),
 dict(k="arrow", i0=17, p0=103.0, i1=20.3, p1=98.8, col=RED, a="target", b="end"),
]
HEAD = [(0,[("when an order block ",INK),("fails...",RED)]),
        ("flips-0.1",[("it ",INK),("flips.",GOLD)]),
        ("breaker0-0.2",[("the ",INK),("breaker block.",RED)]),
        ("bullish-0.3",[("bullish ",GREEN),("order block.",INK)]),
        ("smashes-0.2",[("smashed ",RED),("through.",INK)]),
        ("trapped-0.2",[("buyers ",INK),("trapped.",RED)]),
        ("comes-0.1",[("they sell ",INK),("to escape.",RED)]),
        ("support-0.4",[("support becomes ",INK),("resistance.",RED)]),
        ("sell1-0.1",[("sell ",RED),("the retest.",INK)]),
        ("failed-0.1",[("failed block = ",INK),("next trade.",GOLD)]),
        ("end-0.1",[])]
KEY = {"fails":RED,"flips":GOLD,"breaker":RED,"bullish":GREEN,"defend":GREEN,"smashes":RED,"trapped":RED,"sell":RED,"breakeven":GOLD,
       "support":GREEN,"resistance":RED,"retest":GOLD,"stop":RED,"target":GREEN,"failed":RED}
CAM = [(0.06,0.7,1.25,5.5,105.0),("bullish-0.3",0.6,1.2,7.0,105.0),("smashes-0.3",0.6,1.2,11.5,104.6),("comes-0.3",0.6,1.2,16.0,103.8),("failed-0.3",0.6,1.0,None,None)]
SFX = [("pop","bullish"),("impact","smashes"),("pop","trapped"),("pop","sell0"),("impact","sell1"),("pop","stop"),("ding","target")]
END = dict(l1="a failed block", c1=INK, l2="is your next trade.", c2=GOLD, sub="save this for your next setup")
