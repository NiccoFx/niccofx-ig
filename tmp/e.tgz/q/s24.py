from common import *
C = [(106.8,108.0,106.6,107.7),(107.7,107.9,106.2,106.4),(106.4,106.6,105.0,105.2),(105.2,105.5,104.0,104.3),(104.3,104.6,103.2,103.5),
     (103.5,104.6,103.3,104.4),(104.4,105.5,104.2,105.3),(105.3,105.6,104.6,104.9),(104.9,106.0,104.7,105.8),(105.8,106.8,105.6,106.6),
     (106.6,107.0,106.1,106.4),(106.4,107.4,106.2,107.2),(107.2,108.6,107.0,107.1),(107.1,107.2,106.0,106.2),(106.2,106.4,105.0,105.2),
     (105.2,105.4,104.0,104.3)]
NS, PMIN, PMAX = 17, 102.0, 110.2
EV = dict(end="follow", rejecting="rejecting", right="right", step0=("step",0), step1=("step",1), step2=("step",2), old="old",
          spikes="spikes", wick=("wick",0), body="body", sellers="sellers", sell="sell", stop="stop", target="target", long1=("long",1))
APPEAR = [(0,12,None),(12,13,"spikes"),(13,16,"sell","target+0.6")]
ITEMS = [
 dict(k="badge", i=2.0, p=109.6, n=1, text="key level", col=INK, a="step0", b="end"),
 dict(k="badge", i=2.0, p=108.9, n=2, text="long rejection wick", col=INK, a="step1", b="end"),
 dict(k="badge", i=2.0, p=108.2, n=3, text="small body", col=GOLD, a="step2", b="end"),
 dict(k="hline", i0=-0.4, i1=16.4, p=108.0, col=RED, a="step0", b="end"),
 dict(k="label", i=6.5, p=107.4, text="old resistance", col=RED, a="old", b="end"),
 dict(k="box", i0=11.65, i1=12.35, p0=107.25, p1=108.7, col=GOLD, fill=0.12, a="wick", b="end"),
 dict(k="label", i=14.4, p=109.1, text="long wick", col=GOLD, a="wick", b="end"),
 dict(k="ring", i=12, p=107.1, r=18, col=INK, a="body", b="sell"),
 dict(k="label", i=14.6, p=107.7, text="small body", col=INK, a="body", b="sell"),
 dict(k="ring", i=13, p=107.0, r=20, col=GOLD, a="sell", b="end"),
 dict(k="hline", i0=12.0, i1=16.4, p=107.0, col=GOLD, a="sell", b="end"),
 dict(k="label", i=15.0, p=107.6, text="sell below", col=GOLD, size=22, a="sell", b="end"),
 dict(k="hline", i0=12.0, i1=16.4, p=108.85, col=RED, a="stop", b="end"),
 dict(k="label", i=15.4, p=109.4, text="stop", col=RED, size=22, a="stop", b="end"),
 dict(k="hline", i0=5.0, i1=16.4, p=104.4, col=GREEN, a="target", b="end"),
 dict(k="label", i=10.5, p=103.8, text="target", col=GREEN, size=22, a="target", b="end"),
 dict(k="arrow", i0=13.6, p0=106.6, i1=15.6, p1=104.7, col=RED, a="target", b="end"),
]
HEAD = [(0,[("the pin bar ",INK),("rejection.",RED)]),
        ("right-0.3",[("only at the ",INK),("right level.",GOLD)]),
        ("step0-0.1",[("step 1: ",GOLD),("key level.",INK)]),
        ("step1-0.1",[("step 2: ",GOLD),("long wick.",INK)]),
        ("step2-0.1",[("step 3: ",GOLD),("small body.",INK)]),
        ("sellers-0.2",[("sellers ",RED),("took control.",INK)]),
        ("sell-0.1",[("sell below ",RED),("the low.",INK)]),
        ("long1-0.1",[("wick. level. ",INK),("body.",GOLD)]),
        ("end-0.1",[])]
KEY = {"rejecting":RED,"right":GOLD,"level":GOLD,"resistance":RED,"spikes":RED,"rejected":RED,"wick":GOLD,"body":GOLD,"sellers":RED,
       "sell":RED,"stop":RED,"target":GREEN}
CAM = [(0.06,0.7,1.15,None,106.2),("step1-0.3",0.6,1.3,11.0,107.4),("sell-0.3",0.6,1.15,12.0,106.6),("long1-0.3",0.6,1.0,None,None)]
SFX = [("pop","step0"),("pop","old"),("impact","spikes"),("pop","wick"),("pop","body"),("impact","sell"),("pop","stop"),("ding","target")]
END = dict(l1="long wick, key level,", c1=INK, l2="small body.", c2=GOLD, sub="save this for your next setup")
