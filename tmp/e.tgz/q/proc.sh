set -e
N=$1; URL=$2
mkdir -p /home/user/q/r$N && cd /home/user/q/r$N
curl -sfL "$URL" -o vo_raw.wav
ffmpeg -v error -y -i vo_raw.wav -af "silenceremove=start_periods=1:start_threshold=-45dB,areverse,silenceremove=start_periods=1:start_threshold=-45dB,areverse,highpass=f=80,equalizer=f=220:t=q:w=1:g=-2,equalizer=f=3200:t=q:w=1.2:g=3,acompressor=threshold=-20dB:ratio=3:attack=5:release=80:makeup=2" -ac 1 -ar 48000 -c:a pcm_s16le vo_p.wav
python3 ../wt2.py vo_p.wav wp.json
python3 ../ins.py vo_p.wav wp.json vo_q.wav $3
python3 ../wt2.py vo_q.wav words.json
