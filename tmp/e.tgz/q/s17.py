from common import *
C = [(106.0,106.6,104.8,105.1),(105.1,105.4,103.4,103.7),(103.7,104.0,102.4,102.7),(102.7,103.6,102.0,103.3),(103.3,104.6,103.1,104.3),
     (104.3,104.6,103.0,103.2),(103.2,103.5,102.3,102.5),(102.5,103.8,102.0,103.6),(103.6,105.0,103.4,104.8),(104.8,106.2,104.6,105.9),
     (105.9,106.5,105.2,105.4),(105.4,105.7,104.2,104.5),(104.5,104.8,103.4,103.6),(103.6,104.6,103.4,104.3),(104.3,104.5,102.9,103.1),
     (103.1,103.3,102.2,102.4),(102.4,102.6,100.9,101.4),(101.4,102.2,101.0,101.9)]
NS, PMIN, PMAX = 20, 99.4, 107.8
EV = dict(end="follow", profit0=("profit",0), look="look", equal=("equal",1), support="support", stops0=("stops",0), pool="pool",
          magnet=("magnet",0), short="short", target=("target",0), watch="watch", sell=("sell",1), shift="shift", falls="falls",
          runs="runs", grabs="grabs", profit1=("profit",1), cleaner="cleaner", stop=("stop",0))
APPEAR = [(0,12,None),(12,13,"watch"),(13,14,"shift"),(14,17,"falls","grabs"),(17,18,"profit1")]
ITEMS = [
 dict(k="ring", i=3, p=102.0, r=20, col=GOLD, a="equal", b="falls"),
 dict(k="ring", i=7, p=102.0, r=20, col=GOLD, a="equal+0.15", b="falls"),
 dict(k="hline", i0=2.5, i1=16.6, p=102.0, col=INK, text="equal lows", a="equal", b="end"),
 dict(k="label", i=5, p=101.1, text="support?", col=GREEN, a="support", b="stops0"),
 dict(k="dots", i0=2.6, i1=15.0, p0=101.2, p1=101.7, n=12, col=RED, a="stops0", b="grabs+0.1"),
 dict(k="label", i=5, p=100.5, text="sell stops", col=RED, a="stops0", b="grabs"),
 dict(k="label", i=10.5, p=100.5, text="liquidity pool", col=GOLD, a="pool", b="grabs"),
 dict(k="arrow", i0=13.5, p0=104.6, i1=13.5, p1=102.6, col=GOLD, a="magnet", b="watch"),
 dict(k="label", i=15.4, p=103.6, text="magnet", col=GOLD, a="magnet", b="watch"),
 dict(k="label", i=16.0, p=102.6, text="your target", col=GREEN, a="target", b="watch"),
 dict(k="label", i=13.6, p=105.3, text="shift", col=RED, a="shift", b="falls"),
 dict(k="ring", i=13, p=104.3, r=20, col=GOLD, a="sell", b="end"),
 dict(k="label", i=15.0, p=105.0, text="sell", col=GOLD, a="sell", b="end"),
 dict(k="arrow", i0=13.6, p0=103.9, i1=15.8, p1=101.4, col=RED, a="falls", b="end"),
 dict(k="ring", i=16, p=100.9, r=22, col=GREEN, a="grabs", b="end"),
 dict(k="label", i=17.8, p=100.3, text="take profit", col=GREEN, a="profit1", b="end"),
]
HEAD = [(0,[("where to ",INK),("take profit?",GOLD)]),
        ("look-0.1",[("look for ",INK),("equal lows.",GOLD)]),
        ("support-0.3",[("looks like ",INK),("support...",GREEN)]),
        ("stops0-0.3",[("stops ",RED),("hide below.",INK)]),
        ("pool-0.3",[("a pool of ",INK),("liquidity.",GOLD)]),
        ("short-0.4",[("that's your ",INK),("target.",GREEN)]),
        ("watch-0.1",[("sell ",RED),("after the shift.",INK)]),
        ("runs-0.2",[("stops ",INK),("grabbed.",GOLD)]),
        ("profit1-0.4",[("take ",INK),("profit.",GREEN)]),
        ("cleaner-0.1",[("cleaner = ",INK),("stronger.",GOLD)]),
        ("stop-0.1",[("aim for ",INK),("liquidity.",GOLD)]),
        ("end-0.1",[])]
KEY = {"profit":GREEN,"equal":GOLD,"lows":GOLD,"support":GREEN,"stops":RED,"pool":GOLD,"liquidity":GOLD,"magnet":GOLD,"target":GREEN,
       "sell":RED,"shift":RED,"falls":RED,"grabs":GOLD,"cleaner":GOLD,"stronger":GOLD,"aim":GOLD}
CAM = [(0.06,0.7,1.15,None,103.4),("look-0.3",0.6,1.1,None,103.0),("watch-0.3",0.6,1.2,13.0,103.4),("cleaner-0.3",0.6,1.0,None,None)]
SFX = [("pop","equal"),("pop","support"),("pop","stops0"),("pop","pool"),("pop","target"),("impact","sell"),("ding","grabs")]
END = dict(l1="stop guessing.", c1=INK, l2="aim for liquidity.", c2=GOLD, sub="save this for your next trade")
