#!/usr/bin/env python3
"""Dark trap beat + SFX for NiccoFX reels. Usage: music.py DURATION events.json out_music.wav out_sfx.wav"""
import sys, json, numpy as np, wave

SR = 48000
DUR = float(sys.argv[1])
EV = json.load(open(sys.argv[2]))
N = int(DUR * SR)
rng = np.random.default_rng(7)
BPM = 140.0
BEAT = 60.0 / BPM
BAR = BEAT * 4

def t_arr(n): return np.arange(n) / SR

def add(buf, x, start):
    i = int(start * SR)
    if i >= len(buf): return
    j = min(len(buf), i + len(x))
    buf[i:j] += x[: j - i]

def env(n, a, d):
    t = t_arr(n)
    e = np.minimum(1, t / max(a, 1e-4)) * np.exp(-t / d)
    return e

def lp(x, cut):
    # one-pole lowpass
    a = np.exp(-2 * np.pi * cut / SR)
    y = np.zeros_like(x); s = 0.0
    for k in range(len(x)):
        s = (1 - a) * x[k] + a * s; y[k] = s
    return y

def hp(x, cut): return x - lp(x, cut)

# ---- drum one-shots ----
def kick():
    n = int(0.5 * SR); t = t_arr(n)
    f = 45 + 110 * np.exp(-t / 0.035)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return np.tanh(2.2 * np.sin(ph) * np.exp(-t / 0.22)) * 0.9

def clap():
    n = int(0.35 * SR)
    no = rng.standard_normal(n)
    no = hp(lp(no, 4200), 900)
    e = np.zeros(n)
    for o in (0, 0.012, 0.024):
        e += np.roll(env(n, 0.001, 0.012), int(o * SR))
    e += 0.6 * env(n, 0.002, 0.11)
    return no * e * 0.55

def hat(open_=False):
    n = int((0.18 if open_ else 0.05) * SR)
    no = hp(rng.standard_normal(n), 7000)
    return no * env(n, 0.0005, 0.06 if open_ else 0.012) * 0.22

def sub(freq, length):
    n = int(length * SR); t = t_arr(n)
    f = freq * (1 + 0.5 * np.exp(-t / 0.03))
    ph = 2 * np.pi * np.cumsum(f) / SR
    e = np.minimum(1, t / 0.005) * np.exp(-t / (length * 0.9))
    rel = np.ones(n); r = int(0.04 * SR); rel[-r:] = np.linspace(1, 0, r)
    return np.tanh(1.6 * np.sin(ph)) * e * rel * 0.55

KICK, CLAP, HAT, OHAT = kick(), clap(), hat(), hat(True)

drums = np.zeros(N); bass = np.zeros(N); pad = np.zeros(N)
stop_at = EV.get("break", DUR)      # music drops out (break) here
resume = EV.get("resume", DUR)

F1 = 43.65
prog = [F1, F1 * 2 ** (8 / 12) / 2 * 2 / 2 * 1.0, F1 * 2 ** (3 / 12), F1 * 2 ** (-2 / 12)]  # F, Db, Ab-ish, Eb
prog = [43.65, 34.65, 51.91, 38.89]  # F1, C#1, G#1, D#1
kick_pat = [0, 2.5, 3.0]             # beats in a bar (half-time trap)
t = 0.0; bar = 0
while t < DUR:
    for b in kick_pat:
        tt = t + b * BEAT
        if tt < DUR and not (stop_at <= tt < resume): add(drums, KICK, tt)
    for b in (2,):
        tt = t + b * BEAT
        if tt < DUR and not (stop_at <= tt < resume): add(drums, CLAP, tt)
    # hats: 8ths with 1/16 or triplet roll at bar end
    for k in range(8):
        tt = t + k * BEAT / 2
        if tt < DUR and not (stop_at <= tt < resume): add(drums, HAT * (1.0 if k % 2 == 0 else 0.6), tt)
    if bar % 2 == 1:
        for k in range(6):
            tt = t + 3 * BEAT + k * BEAT / 6
            if tt < DUR and not (stop_at <= tt < resume): add(drums, HAT * 0.7, tt)
    add(drums, OHAT, t + 3.5 * BEAT) if not (stop_at <= t + 3.5 * BEAT < resume) else None
    f = prog[bar % 4]
    for b, L in ((0, 2.4), (2.5, 0.5), (3.0, 1.0)):
        tt = t + b * BEAT
        if tt < DUR and not (stop_at <= tt < resume): add(bass, sub(f, L * BEAT), tt)
    # dark pad (minor triad, detuned saws, lowpassed later)
    n = int(BAR * SR); tp = t_arr(n)
    chord = [f * 4, f * 4 * 2 ** (3 / 12), f * 4 * 2 ** (7 / 12)]
    if bar % 4 == 1: chord[1] = f * 4 * 2 ** (4 / 12)  # major on Db for colour
    x = np.zeros(n)
    for c in chord:
        for det in (-0.12, 0.12):
            ph = (tp * c * 2 ** (det / 12)) % 1.0
            x += (2 * ph - 1)
    e = np.minimum(1, tp / 0.4) * np.minimum(1, (BAR - tp) / 0.3)
    add(pad, x * e * 0.035, t)
    t += BAR; bar += 1

pad = lp(lp(pad, 900), 900)
music = drums * 0.9 + bass * 1.0 + pad * 1.0
# intro filter sweep for first bar is skipped: beat slams in on the hook hit

# ---- SFX ----
sfx = np.zeros(N)
def whoosh(L=0.6):
    n = int(L * SR); tt = t_arr(n)
    no = rng.standard_normal(n)
    cut = 300 + 5000 * np.sin(np.pi * tt / L) ** 2
    y = np.zeros(n); s = 0.0
    for k in range(n):
        a = np.exp(-2 * np.pi * cut[k] / SR); s = (1 - a) * no[k] + a * s; y[k] = s
    return y * np.sin(np.pi * tt / L) ** 1.5 * 0.9
def impact():
    n = int(1.4 * SR); tt = t_arr(n)
    f = 38 + 90 * np.exp(-tt / 0.06)
    boom = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt / 0.45)
    crack = lp(rng.standard_normal(n), 3000) * np.exp(-tt / 0.05) * 0.5
    return np.tanh(1.8 * (boom + crack)) * 0.9
def pop():
    n = int(0.09 * SR); tt = t_arr(n)
    f = 900 + 1400 * np.exp(-tt / 0.01)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt / 0.03) * 0.35
def ding():
    n = int(1.2 * SR); tt = t_arr(n)
    y = sum(np.sin(2 * np.pi * fr * tt) * g for fr, g in ((1568, 1), (2093, 0.6), (3136, 0.3)))
    return y * np.exp(-tt / 0.35) * 0.22
def riser(L):
    n = int(L * SR); tt = t_arr(n)
    no = hp(rng.standard_normal(n), 1500)
    tone = np.sin(2 * np.pi * np.cumsum(200 + 800 * (tt / L) ** 2) / SR)
    return (no * 0.4 + tone * 0.3) * (tt / L) ** 2 * 0.6

W = whoosh(); I = impact(); P = pop(); D = ding()
for kind, at in EV["sfx"]:
    if kind == "whoosh": add(sfx, W, at - 0.3)
    elif kind == "impact": add(sfx, I, at)
    elif kind == "pop": add(sfx, P, at)
    elif kind == "ding": add(sfx, D, at)
    elif kind.startswith("riser"):
        L = float(kind.split(":")[1]); add(sfx, riser(L), at - L)

# fade out tail
fo = int(1.5 * SR); music[-fo:] *= np.linspace(1, 0, fo)

def save(name, x):
    x = x / max(1e-6, np.abs(x).max()) * 0.89
    s = (np.stack([x, x], 1) * 32767).astype(np.int16)
    w = wave.open(name, "wb"); w.setnchannels(2); w.setsampwidth(2); w.setframerate(SR); w.writeframes(s.tobytes()); w.close()
save(sys.argv[3], music); save(sys.argv[4], sfx)
print("ok")
