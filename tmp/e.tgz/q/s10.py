from common import *
C = [(109.0,110.6,108.6,110.2),(110.2,110.4,108.4,108.7),(108.7,109.0,107.2,107.5),(107.5,108.6,106.6,107.8),(107.8,108.0,106.0,106.3),
     (106.3,106.8,104.6,104.9),(104.9,106.1,104.5,105.5),(105.5,106.1,105.0,105.2),(105.2,106.3,104.9,106.0),(106.0,106.6,105.4,105.7),
     (105.7,105.9,104.1,104.3),(104.3,105.5,102.6,102.9),(102.9,104.2,101.8,102.2),(102.2,105.6,102.0,105.3),(105.3,108.9,105.1,108.6),
     (108.6,111.6,108.3,111.2),(111.2,111.5,108.7,109.8),(109.8,110.6,107.6,108.0),(108.0,109.5,105.6,106.0),(106.0,107.8,103.0,103.6),
     (103.6,107.8,103.3,107.4),(107.4,109.6,106.9,109.2),(109.2,111.9,107.6,111.6)]
FVG_OK = [12, 13]
NS, PMIN, PMAX = 25, 99.8, 115.2
EV = dict(CD, real=("real",0), ans=("no",0), reason="reason", look="look", crawls="crawls", power="power", never="never",
          just="just", watch="watch", last="last", push="push", breaks1=("breaks",1), gap1=("gap",1), disp="displacement",
          real1=("real",1), comes="comes", taps="taps", flies="flies", real2=("real",2), fake="fake", so=("so",0), mark=("mark",1))
APPEAR = [(0,6,None),(6,10,"crawls","never"),(10,13,"watch","last+0.4"),(13,15,"push","push+0.5"),(15,16,"breaks1"),
          (16,20,"comes","taps+0.2"),(20,23,"flies","flies+0.8")]
RING = (17, 107.6)
ITEMS = [
 dict(k="hline", i0=-0.4, i1=17.4, p=110.6, col=INK, op=0.55, text="the high", a=0, b="real2-0.3"),
 dict(k="ring", i=5, p=105.7, r=30, col=GOLD, a=0.1, b="ans+0.5"),
 dict(k="label", i=5, p=103.4, text="order block?", col=GOLD, a="real", b="ans+0.5"),
 dict(k="label", i=7.6, p=107.6, text="no power · no gap", col=INK, a="power", b="watch"),
 dict(k="label", i=8.6, p=111.5, text="never breaks the high", col=RED, a="never", b="watch"),
 dict(k="xs", pts=[(5,107.4)], col=RED, a="just", b="watch"),
 dict(k="label", i=5, p=103.4, text="just a red candle", col=RED, a="just", b="watch"),
 dict(k="ring", i=12, p=103.0, r=30, col=GOLD, a="last", b="real1"),
 dict(k="arrow", i0=11.3, p0=103.5, i1=13.4, p1=110.4, col=GREEN, a="push", b="comes"),
 dict(k="label", i=15, p=112.6, text="breaks the high", col=GREEN, a="breaks1", b="comes"),
 dict(k="box", i0=12.6, i1=14.4, p0=104.2, p1=105.1, col=GOLD, fill=0.2, a="gap1", b="real2-0.3"),
 dict(k="label", i=16.6, p=104.65, text="gap", col=GOLD, a="gap1", b="disp+0.6"),
 dict(k="label", i=17.6, p=106.2, text="displacement", col=GREEN, a="disp", b="comes"),
 dict(k="box", i0=11.55, i1=23.5, p0=101.8, p1=104.2, col=GREEN, fill=0.12, a="real1", b="real2-0.3"),
 dict(k="label", i=17.5, p=100.9, text="real order block", col=GREEN, a="real1", b="real2-0.3"),
 dict(k="ring", i=19, p=103.3, r=22, col=GOLD, a="taps", b="real2-0.3"),
 dict(k="arrow", i0=20, p0=104.6, i1=22.6, p1=113.2, col=GREEN, a="flies", b="real2-0.3"),
 dict(k="ring", i=12, p=103.0, r=30, col=GOLD, a="mark", b="end"),
 dict(k="label", i=12, p=100.9, text="this one", col=GOLD, a="mark", b="end"),
]
CMP = dict(a="real2", b="so", cards=[
 dict(title="REAL", col=GREEN, t="real2", seq=[(1000,985,1080,1060),(1060,880,1070,900),(900,760,910,780),(780,740,800,760)],
      zone=(0,985,1080,GREEN), mark="check", l1="breaks structure", l2="leaves a gap"),
 dict(title="FAKE", col=RED, t="fake", seq=[(1000,985,1080,1060),(1060,1020,1075,1035),(1035,1025,1065,1055),(1055,1015,1070,1030),(1030,1020,1130,1110)],
      zone=(0,985,1080,RED), mark="x", l1="no push", l2="no gap")])
HEAD = [(0,[("gold dropped ",INK),("into this.",GOLD)]),
        ("real-0.1",[("real ",INK),("order block?",GOLD)]),
        ("ans-0.05",[("no.",RED)]),
        ("look-0.1",[("no power. ",INK),("no gap.",RED)]),
        ("watch-0.1",[("now ",INK),("watch this.",GOLD)]),
        ("disp-0.2",[("that's ",INK),("displacement.",GREEN)]),
        ("real1-0.1",[("real ",GREEN),("order block.",INK)]),
        ("real2-0.1",[("real ",GREEN),("vs ",INK),("fake.",RED)]),
        ("so-0.1",[("mark what ",INK),("moved price.",GOLD)]),
        ("end-0.1",[])]
KEY = {"no":RED,"power":RED,"push":GREEN,"displacement":GREEN,"breaks":GREEN,"flies":GREEN,"fake":RED,"real":GREEN,
       "moved":GOLD,"block":GOLD,"taps":GOLD,"gap":GOLD}
CAM = [(0.06,0.7,1.4,5.5,106.8),("look-0.3",0.7,1.35,7.0,106.6),("watch-0.3",0.7,1.15,12.5,106.8),("comes-0.3",0.7,1.0,None,None),("mark-0.4",0.6,1.2,12.0,104.8)]
SFX = [("pop","real"),("pop","power"),("pop","just"),("impact","push"),("pop","gap1"),("pop","real1"),("ding","taps"),("pop","mark")]
END = dict(l1="mark the candle", c1=INK, l2="that moved price.", c2=GOLD, sub="save this for your next chart")
