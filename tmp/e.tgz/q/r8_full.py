#!/usr/bin/env python3
"""NiccoFX reel v2 (clean quiz style). Usage: r8.py words.json out.mp4 [--preview t1,t2]"""
import json, sys, math, subprocess, re, os
from PIL import Image, ImageDraw, ImageFont

FONTS = os.environ.get("FONTS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts"))
POP_B = os.path.join(FONTS, "Poppins-Bold.ttf")
POP_M = os.path.join(FONTS, "Poppins-Medium.ttf")
W, H, FPS, SS = 1080, 1920, 30, 2
BG = (201, 201, 201)
INK = (28, 28, 30)
GREEN = (24, 178, 84)
RED = (222, 52, 52)
GOLD = (196, 134, 0)
MUTED = (96, 96, 100)
WICK = (58, 58, 62)

_fc = {}
def font(p, s):
    k = (p, int(s * SS))
    if k not in _fc: _fc[k] = ImageFont.truetype(p, int(s * SS))
    return _fc[k]
def ease(x):
    x = max(0.0, min(1.0, x)); return 1 - (1 - x) ** 3
def eio(x):
    x = max(0.0, min(1.0, x)); return x * x * (3 - 2 * x)
def fade(t, t0, d=0.3): return ease((t - t0) / d)
def sc(v):
    if isinstance(v, tuple): return (v[0] * SS, v[1] * SS)
    return [a * SS for a in v]
def rgba(c, a): return (c[0], c[1], c[2], int(255 * max(0, min(1, a))))

# ---------------- data ----------------
C = [(100,101.4,99.5,101.0),(101.0,102.6,100.6,102.2),(102.2,102.8,101.0,101.4),(101.4,104.0,101.2,103.7),(103.7,105.6,102.6,105.1),
     (105.1,105.8,103.8,104.2),(104.2,106.9,104.0,106.6),(106.6,108.4,105.6,108.0),(108.0,110.0,106.8,109.5),
     (109.5,109.8,107.8,108.2),(108.2,109.0,106.9,107.3),(107.3,108.6,106.6,108.3),(108.3,110.0,108.0,109.7),
     (109.7,109.9,108.4,108.7),(108.7,109.3,107.9,108.9),(108.9,109.8,108.6,109.4),
     (109.4,111.6,109.1,109.6),
     (109.6,109.8,107.4,107.6),(107.6,109.2,106.8,107.0),(107.0,107.6,105.2,105.5),(105.5,106.9,104.6,104.9),(104.9,105.3,103.2,103.6),(103.6,104.7,103.0,104.1)]
N = len(C)
NS = 26
LVL = 110.0
LASTLOW = 107.9
CX0, CX1, CY0, CY1 = 50, 1030, 560, 1360
PMIN, PMAX = 98.6, 112.6
def STEP(): return (CX1 - CX0) / NS
def X(i): return CX0 + i * STEP() + STEP() / 2
def Y(p): return CY1 - (p - PMIN) / (PMAX - PMIN) * (CY1 - CY0)

# ---------------- words ----------------
def norm(w): return re.sub(r"[^a-z0-9']", "", w.lower())
def fix_words(words):
    out = []
    for w, s, e in words:
        n = norm(w)
        if n.startswith("nic") or n.startswith("nik"): w = "niccofx"
        out.append([w, s, e])
    return out
def finder(words):
    def f(tok, which=0, exact=True):
        hits = [w for w in words if (norm(w[0]) == tok if exact else norm(w[0]).startswith(tok))]
        return hits[which][1] if len(hits) > which else 0.0
    return f

def schedule(words):
    f = finder(words)
    ev = dict(
        real=f("real", 0), decide=f("decide"), n3=f("3"), n2=f("2"), n1=f("1"), trap=f("trap"),
        reason=f("reason"), close1=f("close", 0), look=f("look"), everyone=f("everyone"), stops=f("stops"),
        pushes=f("pushes"), grabs=f("grabs"), closes=f("closes"), wick=f("wick", 0), tell=f("tell"),
        acceptance=f("acceptance"), watch=f("watch"), breaks=f("breaks"), low=f("low"),
        confirmation=f("confirmation"), trapped=f("trapped"), realb=f("real", 1), hold=f("hold"),
        fakeouts=f("fakeouts"), fall=f("fall"), dont=f("don't"), wait=f("wait"), end=f("follow"))
    ct = [None] * N
    for i in range(16): ct[i] = -1.0
    ct[16] = 0.15
    ct[17] = ev["breaks"]
    for k, i in enumerate(range(18, N)): ct[i] = ev["confirmation"] + 0.3 + k * (ev["trapped"] + 0.3 - ev["confirmation"] - 0.3) / (N - 19)
    ev["ct"] = ct
    return ev

# ---------------- primitives ----------------
def make_bg():
    im = Image.new("RGB", (W * SS, H * SS), BG)
    # soft radial light in the middle
    ov = Image.new("L", (W // 4, H // 4), 0)
    px = ov.load()
    cx, cy = W / 8, H / 8 * 0.95
    for y in range(H // 4):
        for x in range(W // 4):
            dd = math.hypot((x - cx) / (W / 4), (y - cy) / (H / 4))
            px[x, y] = int(max(0, 1 - dd * 1.6) * 255)
    ov = ov.resize((W * SS, H * SS), Image.BILINEAR)
    light = Image.new("RGB", im.size, (214, 214, 214))
    im = Image.composite(light, im, ov)
    return im

def candle(d, i, prog=1.0, override=None):
    o, h, l, c = override if override else C[i]
    p = ease(prog)
    cc = o + (c - o) * p
    hh = max(o, cc) + (h - max(o, c)) * p if not override else h
    ll = min(o, cc) - (min(o, c) - l) * p if not override else l
    x = X(i); bw = STEP() * 0.58
    col = GREEN if cc >= o else RED
    d.line(sc([x, Y(hh), x, Y(ll)]), fill=WICK, width=int(3 * SS))
    top, bot = Y(max(o, cc)), Y(min(o, cc))
    if bot - top < 3: bot = top + 3
    d.rounded_rectangle(sc([x - bw / 2, top, x + bw / 2, bot]), radius=4 * SS, fill=col)

def dashed(d, x0, y, x1, col, a, w=3, dash=14, gap=10):
    x = x0
    while x < x1:
        d.line(sc([x, y, min(x + dash, x1), y]), fill=rgba(col, a), width=int(w * SS)); x += dash + gap

def label(d, x, y, s, col, a, size=26, anchor="mm", bg=True):
    if a <= 0: return
    f = font(POP_B, size)
    if bg:
        bb = d.textbbox(sc((x, y)), s, font=f, anchor=anchor)
        pad = 12 * SS
        d.rounded_rectangle([bb[0] - pad, bb[1] - pad * 0.6, bb[2] + pad, bb[3] + pad * 0.6], radius=12 * SS,
                            fill=rgba((248, 248, 246), 0.92 * a), outline=rgba(col, a), width=int(2.5 * SS))
    d.text(sc((x, y)), s, font=f, fill=rgba(col, a), anchor=anchor)

def ring(d, x, y, r, col, a, w=3):
    d.ellipse(sc([x - r, y - r, x + r, y + r]), outline=rgba(col, a), width=int(w * SS))

def arrow(d, x0, y0, x1, y1, col, a, w=4, L=18):
    d.line(sc([x0, y0, x1, y1]), fill=rgba(col, a), width=int(w * SS))
    ang = math.atan2(y1 - y0, x1 - x0)
    for s in (-1, 1):
        d.line(sc([x1, y1, x1 - L * math.cos(ang + s * 0.5), y1 - L * math.sin(ang + s * 0.5)]), fill=rgba(col, a), width=int(w * SS))

def check(d, x, y, s, col, a, w=6):
    d.line(sc([x - s, y, x - s * 0.3, y + s * 0.7, x + s, y - s * 0.8]), fill=rgba(col, a), width=int(w * SS), joint="curve")

# ---------------- world (zoomable) ----------------
def world(t, bg, ev):
    im = bg.copy()
    d = ImageDraw.Draw(im, "RGBA")
    panel = fade(t, ev["realb"] - 0.2, 0.35) * (1 - fade(t, ev["dont"] - 0.1, 0.35))
    endA = fade(t, ev["end"], 0.35)

    # key level
    la = 1 - fade(t, ev["confirmation"] + 0.8, 0.4) * 0.6
    dashed(d, X(7.6), Y(LVL), X(18.6), INK, 0.55 * la, w=3)
    if t < ev["look"]:
        d.text(sc((X(18.8), Y(LVL))), "high", font=font(POP_M, 24), fill=rgba(MUTED, la), anchor="lm")

    # equal highs rings
    ea = fade(t, ev["look"], 0.25) * (1 - fade(t, ev["pushes"], 0.3))
    if ea > 0:
        for i in (8, 12):
            ring(d, X(i), Y(C[i][1]) - 2, 20, INK, ea, 3)
        label(d, X(10), Y(111.0), "everyone sees this high", INK, fade(t, ev["everyone"], 0.25) * (1 - fade(t, ev["pushes"], 0.3)), 24)

    # buy stops dots
    sa = fade(t, ev["stops"], 0.25)
    gone = fade(t, ev["grabs"], 0.25)
    if sa > 0 and gone < 1:
        import random
        rnd = random.Random(5)
        for k in range(12):
            px = X(10.5) + rnd.random() * (X(17.2) - X(10.5))
            py = Y(110.25 + rnd.random() * 0.9)
            a = fade(t, ev["stops"] + k * 0.03, 0.12) * (1 - gone)
            d.ellipse(sc([px - 7, py - 7, px + 7, py + 7]), fill=rgba(GOLD, a))
        label(d, X(13.8), Y(111.95), "buy stops", GOLD, sa * (1 - gone), 24)

    # candles (16 special: fake breakout forming, then reveal)
    for i in range(N):
        st = ev["ct"][i]
        if st is None or t < st: continue
        if i == 16:
            if t < ev["trap"]:
                k = ease((t - st) / 1.2)
                o = 109.4; cc = o + (111.2 - o) * k
                candle(d, i, override=(o, max(cc, o) + 0.2 * k, 109.1, cc))
            else:
                k = eio((t - ev["trap"]) / 0.55)
                cc = 111.2 + (109.6 - 111.2) * k
                hh = 111.4 + (111.6 - 111.4) * k
                candle(d, i, override=(109.4, hh, 109.1, cc))
        else:
            candle(d, i, 1.0 if st < 0 else (t - st) / 0.22)

    # countdown ring
    if ev["decide"] <= t < ev["trap"] + 0.3:
        ca = fade(t, ev["decide"], 0.25) * (1 - fade(t, ev["trap"], 0.25))
        cx, cy, r = X(21), Y(105.5), 54
        d.ellipse(sc([cx - r, cy - r, cx + r, cy + r]), fill=rgba((246, 246, 244), 0.9 * ca), outline=rgba(INK, 0.25 * ca), width=int(4 * SS))
        prog = max(0.0, min(1.0, (t - ev["n3"]) / (ev["trap"] - ev["n3"])))
        if t >= ev["n3"]:
            d.arc(sc([cx - r, cy - r, cx + r, cy + r]), start=-90, end=-90 + 360 * (1 - prog), fill=rgba(GOLD, ca), width=int(7 * SS))
        num = "3" if t < ev["n2"] else ("2" if t < ev["n1"] else "1")
        if t < ev["n3"]: num = "?"
        tk = ev["n3"] if num == "3" else (ev["n2"] if num == "2" else ev["n1"])
        bump = 1 + 0.35 * (1 - ease((t - tk) / 0.25)) if num != "?" else 1
        d.text(sc((cx, cy + 2)), num, font=font(POP_B, int(56 * bump)), fill=rgba(INK, ca), anchor="mm")
        d.text(sc((cx, cy + r + 30)), "decide", font=font(POP_M, 24), fill=rgba(MUTED, ca), anchor="mm")

    # trap reveal: wick bracket
    wa = fade(t, ev["wick"], 0.25) * (1 - fade(t, ev["watch"], 0.3))
    if wa > 0:
        x = X(16)
        d.rounded_rectangle(sc([x - 16, Y(111.75), x + 16, Y(109.85)]), radius=10 * SS, outline=rgba(RED, wa), width=int(3 * SS))
        label(d, x + 110, Y(111.2), "the tell", RED, fade(t, ev["tell"], 0.2) * (1 - fade(t, ev["watch"], 0.3)), 24)
    # push arrow + closed inside
    pa = fade(t, ev["pushes"], 0.2) * (1 - fade(t, ev["wick"], 0.3))
    if pa > 0:
        p = ease((t - ev["pushes"]) / 0.5)
        y0 = Y(109.2); y1 = Y(109.2) + (Y(111.5) - Y(109.2)) * p
        arrow(d, X(16) - 34, y0, X(16) - 34, y1, GREEN, pa, w=4)
        label(d, X(13.4), Y(111.2), "liquidity grabbed", GOLD, fade(t, ev["grabs"], 0.2) * (1 - fade(t, ev["wick"], 0.3)), 24)
    ia = fade(t, ev["closes"], 0.2) * (1 - fade(t, ev["watch"], 0.3))
    if ia > 0:
        d.line(sc([X(16) - 22, Y(109.6), X(16) + 22, Y(109.6)]), fill=rgba(RED, ia), width=int(4 * SS))
        label(d, X(16) + 120, Y(109.0), "closed inside", RED, ia, 24)

    # last low + break
    ll = fade(t, ev["watch"], 0.25) * (1 - fade(t, ev["realb"] - 0.3, 0.3))
    if ll > 0:
        broken = t >= ev["low"]
        col = RED if broken else INK
        dashed(d, X(13.6), Y(LASTLOW), X(19.2), col, ll, w=3)
        d.text(sc((X(19.4), Y(LASTLOW))), "broken" if broken else "last low", font=font(POP_B if broken else POP_M, 24), fill=rgba(col, ll), anchor="lm")
    cf = fade(t, ev["confirmation"], 0.2) * (1 - fade(t, ev["realb"] - 0.3, 0.3))
    if cf > 0:
        label(d, X(20.5), Y(108.9), "confirmation", GREEN, cf, 26)
    tr = fade(t, ev["trapped"], 0.2) * (1 - fade(t, ev["realb"] - 0.3, 0.3))
    if tr > 0:
        for k, dx in enumerate((-30, 0, 30)):
            x0 = X(16) + dx; y0 = Y(111.95)
            a = fade(t, ev["trapped"] + 0.06 * k, 0.12) * tr
            d.line(sc([x0 - 9, y0 - 9, x0 + 9, y0 + 9]), fill=rgba(RED, a), width=int(4 * SS))
            d.line(sc([x0 - 9, y0 + 9, x0 + 9, y0 - 9]), fill=rgba(RED, a), width=int(4 * SS))
        label(d, X(16), Y(112.35), "buyers trapped", RED, tr, 24)

    # final: wait for the close marker on candle 16
    wf = fade(t, ev["wait"], 0.25) * (1 - endA)
    if wf > 0:
        x = X(16)
        ring(d, x, Y(109.6), 22, GOLD, wf, 4)
        label(d, x - 150, Y(111.3), "wait for this", GOLD, wf, 24)

    # comparison panel (screen-filling card inside world space)
    if panel > 0:
        d.rectangle(sc([0, 470, W, 1430]), fill=rgba(BG, 0.96 * panel))
        draw_compare(d, t, ev, panel)
    return im

def draw_compare(d, t, ev, a):
    cards = [(60, 520, "REAL", GREEN, ev["realb"], "close above", "& hold"),
             (560, 1020, "FAKE", RED, ev["fakeouts"], "wick above", "& fall back")]
    for x0, x1, title, col, t0, l1, l2 in cards:
        ca = fade(t, t0, 0.3) * a
        if ca <= 0: continue
        y0, y1 = 520, 1400
        d.rounded_rectangle(sc([x0, y0, x1, y1]), radius=28 * SS, fill=rgba((244, 244, 242), 0.95 * ca), outline=rgba(col, ca), width=int(3 * SS))
        d.text(sc(((x0 + x1) / 2, y0 + 70)), title, font=font(POP_B, 54), fill=rgba(col, ca), anchor="mm")
        lv = 980
        dashed(d, x0 + 40, lv, x1 - 40, INK, 0.6 * ca, w=3)
        bw = 46
        def cnd(cx, o, h, l, c, prog):
            p = ease(prog)
            cc = o + (c - o) * p
            hh = max(o, cc) - (max(o, cc) - h) * p
            ll = min(o, cc) + (l - min(o, cc)) * p
            colc = GREEN if c < o else RED   # y grows downward: c<o means up
            d.line(sc([cx, hh, cx, ll]), fill=rgba(WICK, ca), width=int(3 * SS))
            top, bot = min(o, cc), max(o, cc)
            d.rounded_rectangle(sc([cx - bw / 2, top, cx + bw / 2, max(bot, top + 3)]), radius=5 * SS, fill=rgba(colc, ca))
        mid = (x0 + x1) / 2
        k1 = (t - t0 - 0.25) / 0.35; k2 = (t - t0 - 0.75) / 0.35
        if title == "REAL":
            cnd(mid - 90, 1080, 1100, 1120, 1060, 1)
            cnd(mid - 20, 1060, 1010, 1080, 1020, 1)
            if k1 > 0: cnd(mid + 50, 1020, 860, 1030, 880, k1)
            if k2 > 0: cnd(mid + 120, 880, 820, 930, 840, k2)
            if k2 > 0.8: check(d, mid + 150, 760, 18, GREEN, ca)
        else:
            cnd(mid - 90, 1080, 1100, 1120, 1060, 1)
            cnd(mid - 20, 1060, 1010, 1080, 1020, 1)
            if k1 > 0: cnd(mid + 50, 1020, 860, 1030, 1000, k1)
            if k2 > 0: cnd(mid + 120, 1000, 990, 1180, 1160, k2)
            if k2 > 0.8:
                d.line(sc([mid + 140, 752, mid + 168, 780]), fill=rgba(RED, ca), width=int(5 * SS))
                d.line(sc([mid + 140, 780, mid + 168, 752]), fill=rgba(RED, ca), width=int(5 * SS))
        d.text(sc((mid, y1 - 150)), l1, font=font(POP_B, 38), fill=rgba(INK, ca), anchor="mm")
        d.text(sc((mid, y1 - 100)), l2, font=font(POP_B, 38), fill=rgba(col, ca), anchor="mm")

# ---------------- camera ----------------
def cam_keys(ev):
    D = (1.0, 540, 960)
    return [
        (0.0, 0.01, 1.14, 540, 900),
        (0.05, 0.6, 1.0, 540, 960),
        (ev["close1"] - 0.3, 0.8, 1.55, X(14.5), Y(109.6) + 60),
        (ev["watch"] - 0.2, 0.7, 1.22, X(16.5), Y(107.5) + 80),
        (ev["trapped"] + 0.2, 0.7, 1.0, 540, 960),
        (ev["wait"] - 0.4, 0.6, 1.25, X(15), Y(108.5) + 60),
        (ev["end"] - 0.2, 0.4, 1.0, 540, 960),
    ]

def camera(t, ev):
    keys = cam_keys(ev)
    s, cx, cy = keys[0][2], keys[0][3], keys[0][4]
    for t0, dur, s1, x1, y1 in keys:
        if t >= t0:
            k = eio((t - t0) / dur)
            s, cx, cy = s + (s1 - s) * k, cx + (x1 - cx) * k, cy + (y1 - cy) * k
    # punch on trap
    if t >= ev["trap"]: s += 0.05 * (1 - ease((t - ev["trap"]) / 0.35))
    return s, cx, cy

# ---------------- UI (screen space) ----------------
HEAD = None
def headlines(ev):
    return [
        (0.0, [("gold just ", INK), ("broke out.", GOLD)]),
        (ev["real"] - 0.1, [("real ", INK), ("breakout?", GOLD)]),
        (ev["trap"] - 0.05, [("it's a ", INK), ("trap.", RED)]),
        (ev["close1"] - 0.1, [("it's the ", INK), ("close.", GOLD)]),
        (ev["stops"] - 0.1, [("buy stops ", GOLD), ("above the high.", INK)]),
        (ev["grabs"] - 0.1, [("liquidity ", GOLD), ("grabbed.", INK)]),
        (ev["acceptance"] - 0.2, [("no ", INK), ("acceptance.", RED)]),
        (ev["breaks"] - 0.1, [("structure ", INK), ("shift.", RED)]),
        (ev["realb"] - 0.1, [("real ", GREEN), ("vs ", INK), ("fake.", RED)]),
        (ev["wait"] - 0.15, [("wait for the ", INK), ("close.", GOLD)]),
        (ev["end"] - 0.1, []),
    ]

def draw_head(d, t, ev):
    hs = headlines(ev)
    cur, nxt = None, None
    for k, (t0, segs) in enumerate(hs):
        if t >= t0: cur = (t0, segs, hs[k + 1][0] if k + 1 < len(hs) else 999)
    if not cur or not cur[1]: return
    t0, segs, t1 = cur
    a = fade(t, t0, 0.25) * (1 - fade(t, t1 - 0.15, 0.15))
    rise = 16 * (1 - ease((t - t0) / 0.3))
    f = font(POP_B, 66)
    total = sum(d.textlength(s, font=f) for s, _ in segs) / SS
    x = W / 2 - total / 2
    for s, col in segs:
        d.text(sc((x, 330 + rise)), s, font=f, fill=rgba(col, a), anchor="lm")
        x += d.textlength(s, font=f) / SS

KEY = {"real": GOLD, "breakout": GOLD, "trap": RED, "close": GOLD, "stops": GOLD, "grabs": GOLD, "wick": RED,
       "tell": RED, "acceptance": RED, "breaks": RED, "low": RED, "confirmation": GREEN, "trapped": RED,
       "hold": GREEN, "fakeouts": RED, "fall": RED, "wait": GOLD, "niccofx": GOLD, "decide": GOLD}

def chunks(words):
    out, cur = [], []
    for w in words:
        cur.append(w)
        if len(cur) >= 5 or re.search(r"[.?!,]$", w[0]):
            out.append(cur); cur = []
    if cur: out.append(cur)
    return out

def draw_caption(d, t, chs, end_t):
    cur = None
    for k, ch in enumerate(chs):
        nxt = chs[k + 1][0][1] if k + 1 < len(chs) else end_t
        if ch[0][1] - 0.08 <= t < nxt - 0.02: cur = ch
    if not cur: return
    f = font(POP_B, 48)
    words = [w[0] for w in cur]
    sp = d.textlength(" ", font=f) / SS
    widths = [d.textlength(w, font=f) / SS for w in words]
    total = sum(widths) + sp * (len(words) - 1)
    x = W / 2 - total / 2
    ca = fade(t, cur[0][1] - 0.08, 0.12)
    for (w, st, en), ww in zip(cur, widths):
        if t >= st:
            nx = [q for q in cur if q[1] > st]
            active = t < (nx[0][1] if nx else st + 0.6)
            col = KEY.get(norm(w), INK) if not active else (KEY.get(norm(w), GOLD) if norm(w) in KEY else GOLD)
            col = col if active or norm(w) in KEY else INK
            a = 1.0
        else:
            col, a = INK, 0.35
        d.text(sc((x, 1545)), w, font=f, fill=rgba(col, a * ca), anchor="lm")
        x += ww + sp

def draw_ui(d, t, ev, chs, end_t):
    d.ellipse(sc([60, 92, 76, 108]), fill=GOLD)
    d.text(sc((88, 100)), "@niccofx", font=font(POP_M, 30), fill=INK, anchor="lm")
    draw_head(d, t, ev)
    ea = fade(t, ev["end"], 0.35)
    if ea > 0:
        d.rectangle(sc([0, 150, W, 1480]), fill=rgba(BG, 0.97 * ea))
        f1 = font(POP_B, 84)
        d.text(sc((W / 2, 620)), "wait for", font=f1, fill=rgba(INK, ea), anchor="mm")
        d.text(sc((W / 2, 720)), "the close.", font=f1, fill=rgba(GOLD, ea), anchor="mm")
        a2 = fade(t, ev["end"] + 0.35, 0.3)
        fb = font(POP_B, 52)
        tw = d.textlength("Follow @niccofx", font=fb) / SS
        d.rounded_rectangle(sc([W / 2 - tw / 2 - 34, 850, W / 2 + tw / 2 + 34, 950]), radius=50 * SS, fill=rgba(INK, a2))
        d.text(sc((W / 2, 900)), "Follow @niccofx", font=fb, fill=rgba((245, 245, 245), a2), anchor="mm")
        d.text(sc((W / 2, 1030)), "save this for your next breakout", font=font(POP_M, 34), fill=rgba(MUTED, a2), anchor="mm")
    else:
        draw_caption(d, t, chs, end_t)
    d.text(sc((W / 2, 1860)), "Education only · Not financial advice", font=font(POP_M, 22), fill=rgba(MUTED, 0.8), anchor="mm")

def frame(t, bg, ev, chs, end_t):
    im = world(t, bg, ev)
    s, cx, cy = camera(t, ev)
    if s > 1.001:
        Wd, Hd = im.size
        cw, ch = Wd / s, Hd / s
        px, py = cx * SS, cy * SS
        px = min(max(px, cw / 2), Wd - cw / 2); py = min(max(py, ch / 2), Hd - ch / 2)
        im = im.resize((Wd, Hd), Image.BILINEAR, box=(px - cw / 2, py - ch / 2, px + cw / 2, py + ch / 2))
    d = ImageDraw.Draw(im, "RGBA")
    draw_ui(d, t, ev, chs, end_t)
    return im.resize((W, H), Image.LANCZOS)

G = {}
def _init(p):
    words = fix_words(json.load(open(p)))
    G["ev"] = schedule(words); G["chs"] = chunks(words)
    G["end_t"] = words[-1][2] + 1.8; G["bg"] = make_bg()
def _render(k): return frame(k / FPS, G["bg"], G["ev"], G["chs"], G["end_t"]).tobytes()

def main():
    _init(sys.argv[1]); out = sys.argv[2]
    if "--preview" in sys.argv:
        ts = [float(x) for x in sys.argv[sys.argv.index("--preview") + 1].split(",")]
        for k, tt in enumerate(ts):
            frame(tt, G["bg"], G["ev"], G["chs"], G["end_t"]).save(out.replace(".mp4", f"_p{k}.png"))
        print(json.dumps({k: round(v, 2) for k, v in G["ev"].items() if k != "ct"}))
        return
    nfr = int(G["end_t"] * FPS)
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-",
           "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "17", "-preset", "medium", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    from multiprocessing import Pool
    with Pool(os.cpu_count(), initializer=_init, initargs=(sys.argv[1],)) as pool:
        for b in pool.imap(_render, range(nfr), chunksize=6): p.stdin.write(b)
    p.stdin.close(); p.wait(); print("done", out, nfr / FPS)

if __name__ == "__main__":
    main()
