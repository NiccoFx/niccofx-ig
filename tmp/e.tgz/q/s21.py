from common import *
C = [(103.2,104.0,102.8,103.8),(103.8,104.6,103.5,104.3),(104.3,104.9,103.7,103.9),(103.9,104.2,103.1,103.4),(103.4,104.3,103.2,104.1),
     (104.1,105.0,103.9,104.7),(104.7,104.9,103.8,104.0),(104.0,104.5,103.4,103.6),(103.6,104.4,103.3,104.2),(104.2,104.8,103.9,104.5),
     (104.5,104.7,103.7,103.9),(103.9,104.6,103.6,104.4),(104.4,106.0,104.2,105.8),(105.8,107.4,105.5,107.1),(107.1,108.2,106.8,107.6),
     (107.6,107.8,106.5,106.7),(106.7,106.9,105.4,105.6),(105.6,105.8,104.4,104.6),(104.6,104.9,103.8,104.1),(104.1,104.7,103.8,104.4),
     (104.4,104.6,103.9,104.2)]
FVG_OK = [11, 12]
NS, PMIN, PMAX = 26, 100.8, 110.0
BINS = [(102.0,0.8),(102.5,1.4),(103.0,2.4),(103.5,3.2),(104.0,4.0),(104.5,3.0),(105.0,2.0),(105.5,1.2),(106.0,0.9),(106.5,0.8),(107.0,0.9),(107.5,0.7),(108.0,0.4)]
EV = dict(end="follow", why="why", control="control", profile="profile", most="most", agreed="agreed", value="value", balance="balance",
          watch="watch", spikes="spikes", buyers=("buyers",1), pulled="pulled", magnet="magnet", target="target", support="support")
APPEAR = [(0,12,None),(12,15,"spikes","buyers"),(15,19,"pulled","magnet"),(19,21,"magnet+0.3","target")]
UNDER = [dict(k="box", i0=-0.4, i1=21.2, p0=103.0, p1=105.0, col=GOLD, fill=0.08, line=False, a="value", b="end")]
ITEMS = [
 dict(k="vp", i=21.4, bins=BINS, poc=104.0, va=(103.0, 105.0), a="profile", b="end"),
 dict(k="hline", i0=-0.4, i1=21.3, p=104.0, col=GOLD, a="control", b="end"),
 dict(k="label", i=19.6, p=105.5, text="POC", col=GOLD, size=26, a="control", b="end"),
 dict(k="label", i=23.4, p=109.0, text="volume profile", col=INK, size=22, a="profile", b="end"),
 dict(k="label", i=23.0, p=101.3, text="most volume", col=GOLD, size=22, a="most", b="end"),
 dict(k="label", i=6.0, p=106.2, text="fair value", col=GOLD, a="value", b="watch"),
 dict(k="label", i=11.0, p=109.0, text="out of balance", col=RED, a="balance", b="pulled"),
 dict(k="arrow", i0=15.6, p0=108.2, i1=17.9, p1=104.6, col=GOLD, a="pulled", b="end"),
 dict(k="label", i=19.0, p=107.2, text="magnet", col=GOLD, a="magnet", b="end"),
 dict(k="label", i=6.0, p=107.6, text="far away = target", col=GREEN, a="target", b="end"),
 dict(k="label", i=6.0, p=101.8, text="near = support / resistance", col=INK, a="support", b="end"),
]
HEAD = [(0,[("price keeps ",INK),("coming back.",GOLD)]),
        ("control-0.5",[("the ",INK),("point of control.",GOLD)]),
        ("most-0.3",[("most volume ",GOLD),("traded here.",INK)]),
        ("value-0.5",[("fair ",INK),("value.",GOLD)]),
        ("balance-0.6",[("too far = ",INK),("out of balance.",RED)]),
        ("watch-0.1",[("watch the ",INK),("magnet.",GOLD)]),
        ("target-0.3",[("POC = ",GOLD),("target or S/R.",INK)]),
        ("end-0.1",[])]
KEY = {"control":GOLD,"poc":GOLD,"volume":GOLD,"value":GOLD,"balance":RED,"spikes":RED,"pulled":GOLD,"magnet":GOLD,"target":GREEN,"support":INK}
CAM = [(0.06,0.7,1.1,None,104.8),("watch-0.3",0.6,1.2,15.0,106.0),("target-0.3",0.6,1.0,None,None)]
SFX = [("pop","control"),("whoosh","profile"),("pop","most"),("pop","value"),("impact","spikes"),("impact","pulled"),("ding","magnet")]
END = dict(l1="price always", c1=INK, l2="returns to value.", c2=GOLD, sub="save this for your next chart")
