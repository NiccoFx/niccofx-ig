from common import *
C = [(100.4,101.6,100.0,101.3),(101.3,102.2,100.9,101.9),(101.9,102.4,101.2,101.5),(101.5,103.2,101.3,102.9),(102.9,104.4,102.6,104.1),
     (104.1,104.6,103.4,103.8),(103.8,106.0,103.6,105.7),
     (105.7,106.6,105.6,106.3),(106.3,106.8,105.9,106.0),(106.0,106.5,105.7,106.4),(106.4,106.7,105.8,105.9),(105.9,106.3,105.6,106.2),
     (106.2,106.8,106.0,106.1),(106.1,106.6,105.7,105.8),(105.8,106.4,105.6,106.3),(106.3,106.7,105.9,106.0),
     (106.0,106.2,104.3,104.6),(104.6,105.9,104.1,105.7),(105.7,107.6,105.5,107.3),(107.3,109.0,107.0,108.7),(108.7,110.4,108.4,110.1),
     (110.1,110.6,109.2,109.5),(109.5,111.4,109.3,111.1)]
NS, PMIN, PMAX = 25, 99.0, 113.4
EV = dict(CD, london=("london",0), where="where", ans=("down",1), reason="reason", asian="asian", look="look", stops="stops",
          below="below", opens="opens", dives="dives", grabs="grabs", rips="rips", first=("first",1), realup=("real",0),
          trap1=("trap",1), real1=("real",1), so=("so",0))
APPEAR = [(0,16,None),(16,17,"dives"),(17,18,"grabs"),(18,23,"rips","first")]
RING = (21.5, 103.6)
ITEMS = [
 dict(k="arrow", i0=16, p0=107.4, i1=17.6, p1=110.0, col=GREEN, a="where", b="ans+0.4"),
 dict(k="label", i=18.6, p=110.8, text="up?", col=GREEN, a="where", b="ans+0.4"),
 dict(k="arrow", i0=16, p0=105.1, i1=17.6, p1=102.6, col=RED, a="where+0.3", b="ans+0.4"),
 dict(k="label", i=18.8, p=102.0, text="down?", col=RED, a="where+0.3", b="ans+0.4"),
 dict(k="box", i0=6.55, i1=15.45, p0=105.6, p1=106.8, col=GOLD, fill=0.14, a="asian", b="trap1-0.3"),
 dict(k="label", i=11, p=108.4, text="asian range", col=GOLD, a="asian", b="stops"),
 dict(k="dots", i0=7.2, i1=15.2, p0=107.0, p1=107.6, n=9, col=GOLD, a="stops", b="trap1-0.3"),
 dict(k="label", i=11, p=108.4, text="buy stops", col=GOLD, a="stops", b="opens"),
 dict(k="dots", i0=7.2, i1=15.2, p0=104.8, p1=105.4, n=9, seed=9, col=RED, a="below", b="grabs+0.1"),
 dict(k="label", i=11, p=104.0, text="sell stops", col=RED, a="below", b="grabs+0.1"),
 dict(k="vline", i=15.5, p0=101.6, p1=110.8, col=INK, text="London open", a="opens", b="trap1-0.3"),
 dict(k="ring", i=17, p=104.1, r=22, col=RED, a="grabs", b="trap1-0.3"),
 dict(k="label", i=19.4, p=104.0, text="sweep", col=RED, a="grabs", b="trap1-0.3"),
 dict(k="arrow", i0=18, p0=106.2, i1=22.4, p1=112.4, col=GREEN, a="rips", b="trap1-0.3"),
 dict(k="label", i=13.2, p=103.0, text="trap", col=RED, a="first", b="trap1-0.3"),
 dict(k="label", i=19.4, p=112.6, text="real move", col=GREEN, a="realup", b="trap1-0.3"),
]
CMP = dict(a="trap1", b="so", cards=[
 dict(title="TRAP", col=RED, t="trap1", level=975,
      seq=[(950,935,975,960),(960,940,970,945),(945,935,965,955),(955,950,1090,1075)],
      mark="x", l1="takes", l2="liquidity"),
 dict(title="REAL", col=GREEN, t="real1", level=975,
      seq=[(950,935,975,960),(960,955,1060,1045),(1045,900,1070,915),(915,800,925,815),(815,720,830,735)],
      mark="check", l1="follows", l2="the trend")])
HEAD = [(0,[("gold is ",INK),("trending up.",GREEN)]),
        ("london-0.1",[("london ",INK),("opens soon.",GOLD)]),
        ("where-0.1",[("up ",GREEN),("or ",INK),("down?",RED)]),
        ("ans-0.05",[("down first.",RED)]),
        ("reason-0.1",[("it's the ",INK),("asian range.",GOLD)]),
        ("stops-0.1",[("stops ",GOLD),("on both sides.",INK)]),
        ("opens-0.1",[("london ",INK),("opens.",GOLD)]),
        ("grabs-0.1",[("sell stops ",RED),("grabbed.",INK)]),
        ("rips-0.1",[("then it ",INK),("rips.",GREEN)]),
        ("trap1-0.1",[("trap ",RED),("vs ",INK),("real move.",GREEN)]),
        ("so-0.1",[("wait for ",INK),("the sweep.",GOLD)]),
        ("end-0.1",[])]
KEY = {"trending":GREEN,"up":GREEN,"down":RED,"asian":GOLD,"box":GOLD,"stops":GOLD,"dives":RED,"grabs":RED,"rips":GREEN,
       "trap":RED,"real":GREEN,"liquidity":GOLD,"trend":GREEN,"sweep":GOLD,"london":GOLD}
CAM = [("look-0.3",0.7,1.4,11.0,106.2),("opens-0.3",0.6,1.2,16.0,106.4),("rips-0.2",0.6,1.0,None,None)]
SFX = [("pop","asian"),("pop","stops"),("pop","below"),("impact","dives"),("pop","grabs"),("impact","rips")]
END = dict(l1="wait for", c1=INK, l2="the sweep.", c2=GOLD, sub="send this to a trader who chases London")
