import sys, math, importlib
sys.argv = ["x"]
import r8 as B
from r8 import *
from PIL import Image, ImageDraw
WHITE = (250, 250, 248)
def load(n):
    S = importlib.import_module(f"s{n}")
    C = [list(c) for c in getattr(S, "C", [])]
    ok = set(getattr(S, "FVG_OK", []))
    for i in range(len(C) - 2):
        if i in ok: continue
        if C[i+2][2] > C[i][1]: C[i+2][2] = round(C[i][1] - 0.15, 2)
        if C[i+2][1] < C[i][3] and C[i+2][1] < C[i][2]: C[i+2][1] = round(C[i][2] + 0.15, 2)
    return S, [tuple(c) for c in C]
def setup(C, ns, pmin, pmax, box=(70, 1010, 640, 1480), upto=None):
    B.C = C[:upto] if upto else C; B.N = len(B.C); B.NS = ns
    B.CX0, B.CX1, B.CY0, B.CY1 = box; B.PMIN, B.PMAX = pmin, pmax
def bigarrow(d, x0, y0, x1, y1, col, w=30, head=70):
    ang = math.atan2(y1 - y0, x1 - x0); ca, sa = math.cos(ang), math.sin(ang)
    bx, by = x1 - head * ca, y1 - head * sa
    nx, ny = -sa, ca
    pts = [(x0 + nx*w/2, y0 + ny*w/2), (bx + nx*w/2, by + ny*w/2), (bx + nx*head*0.75, by + ny*head*0.75), (x1, y1),
           (bx - nx*head*0.75, by - ny*head*0.75), (bx - nx*w/2, by - ny*w/2), (x0 - nx*w/2, y0 - ny*w/2)]
    d.polygon([sc(p) for p in pts], fill=col, outline=INK, width=int(5*SS))
def word(d, x, y, s, col, size=150, stroke=8, anchor="mm"):
    d.text(sc((x, y)), s, font=font(POP_B, size), fill=col, anchor=anchor, stroke_width=int(stroke*SS), stroke_fill=WHITE)
def tag(d, x, y, s, col, size=64):
    f = font(POP_B, size); tw = d.textlength(s, font=f) / SS
    d.rounded_rectangle(sc([x - tw/2 - 28, y - size*0.72, x + tw/2 + 28, y + size*0.72]), radius=22*SS, fill=col)
    d.text(sc((x, y + 2)), s, font=f, fill=WHITE, anchor="mm")
def zone(d, i0, i1, p0, p1, col, a=0.22):
    d.rounded_rectangle(sc([B.X(i0), B.Y(p1), B.X(i1), B.Y(p0)]), radius=12*SS, fill=rgba(col, a), outline=rgba(col, 1), width=int(5*SS))
def hl(d, i0, i1, p, col, w=6, dash=False):
    if dash: dashed(d, B.X(i0), B.Y(p), B.X(i1), col, 1, w=w, dash=26, gap=16)
    else: d.line(sc([B.X(i0), B.Y(p), B.X(i1), B.Y(p)]), fill=col, width=int(w*SS))
def candles(d):
    for i in range(B.N): B.candle(d, i)
def brand(d):
    d.ellipse(sc([60, 92, 76, 108]), fill=GOLD); d.text(sc((88, 100)), "NiccoFX", font=font(POP_B, 32), fill=INK, anchor="lm")
def new():
    bg = B.make_bg(); return bg, ImageDraw.Draw(bg, "RGBA")
def save(bg, n):
    bg.resize((W, H), Image.LANCZOS).save(f"covers/cover{n}.jpg", quality=92)

# ---- 10 order block
S, C = load(10); bg, d = new(); setup(C, 23, 99.8, 115.2, upto=23)
zone(d, 11.55, 22.6, 101.8, 104.2, GREEN, 0.18); hl(d, -0.4, 17, 110.6, INK, 5, True); candles(d)
bigarrow(d, B.X(6.5), B.Y(97.6), B.X(11.2), B.Y(102.6), GREEN)
word(d, 540, 400, "REAL OB?", INK, 170); tag(d, 540, 1660, "or just a red candle", RED, 54); brand(d); save(bg, 10)
# ---- 11 win rate
bg, d = new(); brand(d)
word(d, 540, 380, "80% vs 40%", INK, 140)
for cx, tp, sl, col, nm in ((290, 60, 300, RED, "A"), (790, 330, 100, GREEN, "B")):
    y = 1060
    d.rounded_rectangle(sc([cx - 170, y - tp, cx + 170, y]), radius=14*SS, fill=rgba(GREEN, 0.75))
    d.rounded_rectangle(sc([cx - 170, y, cx + 170, y + sl]), radius=14*SS, fill=rgba(RED, 0.75))
    d.line(sc([cx - 190, y, cx + 190, y]), fill=INK, width=int(6*SS))
    tag(d, cx, 600, f"TRADER {nm}", INK, 52)
word(d, 290, 1500, "-$40", RED, 120, 6); word(d, 790, 1500, "+$600", GREEN, 120, 6)
tag(d, 540, 1680, "who makes more?", GOLD, 54); save(bg, 11)
# ---- 12 BOS vs CHoCH
S, C = load(12); bg, d = new(); setup(C, 26, 99.2, 114.4)
candles(d); hl(d, 12.6, 19.6, 110.6, GREEN, 6); hl(d, 15.6, 24.6, 107.8, RED, 6)
word(d, B.X(15.2), B.Y(110.6) - 70, "BOS", GREEN, 110, 6); word(d, B.X(21.0), B.Y(107.8) + 150, "CHoCH", RED, 100, 6)
bigarrow(d, B.X(23.5), B.Y(113.8), B.X(22.3), B.Y(108.4), RED, 26, 60)
word(d, 540, 400, "TREND OVER?", INK, 130); brand(d); save(bg, 12)
# ---- 13 London open
S, C = load(13); bg, d = new(); setup(C, 24, 99.0, 113.4, upto=16)
zone(d, 6.55, 15.45, 105.6, 106.8, GOLD, 0.2); candles(d)
d.line(sc([B.X(15.5), B.Y(112), B.X(15.5), B.Y(100)]), fill=INK, width=int(4*SS))
bigarrow(d, B.X(16.4), B.Y(107.2), B.X(21.0), B.Y(111.8), GREEN); bigarrow(d, B.X(16.4), B.Y(105.2), B.X(21.0), B.Y(100.6), RED)
word(d, B.X(21.7), B.Y(109.4), "?", INK, 200, 8)
word(d, 540, 360, "LONDON", GOLD, 160); word(d, 540, 520, "OPEN", INK, 140); brand(d); save(bg, 13)
# ---- 14 stop A or B
S, C = load(14); bg, d = new(); setup(C, 18, 99.6, 112.6, upto=14)
candles(d); hl(d, 9.5, 17.5, 103.8, RED, 7, True); hl(d, 9.5, 17.5, 102.4, GREEN, 7, True)
tag(d, B.X(16.4), B.Y(103.8), "A", RED, 70); tag(d, B.X(16.4), B.Y(102.4) + 10, "B", GREEN, 70)
bigarrow(d, B.X(16.6), B.Y(109.2), B.X(13.4), B.Y(106.2), GOLD, 26, 60)
word(d, 540, 380, "YOUR STOP?", INK, 140); tag(d, 540, 1640, "A or B", GOLD, 70); brand(d); save(bg, 14)
# ---- 15 OTE
S, C = load(15); bg, d = new(); setup(C, 21, 98.8, 114.0, upto=17)
zone(d, 11.4, 20.6, 102.5, 104.11, GOLD, 0.25); candles(d)
for p, t in ((104.11, "62%"), (102.5, "79%")): d.text(sc((B.X(20.0), B.Y(p))), t, font=font(POP_B, 40), fill=GOLD, anchor="rm")
d.line(sc([B.X(6), B.Y(100.5), B.X(11), B.Y(110)]), fill=GOLD, width=int(6*SS))
bigarrow(d, B.X(19.5), B.Y(110.5), B.X(16.6), B.Y(104.6), GREEN)
word(d, 540, 400, "OTE ZONE", GOLD, 170); tag(d, 540, 1640, "where smart money buys", INK, 54); brand(d); save(bg, 15)
# ---- 16 breaker
S, C = load(16); bg, d = new(); setup(C, 21, 97.4, 110.6, upto=18)
zone(d, 4.55, 20.4, 104.0, 104.9, RED, 0.22); candles(d)
bigarrow(d, B.X(19.0), B.Y(109.0), B.X(16.3), B.Y(105.4), RED)
word(d, 540, 400, "BREAKER", RED, 170); tag(d, 540, 1640, "when an OB fails", INK, 56); brand(d); save(bg, 16)
# ---- 17 equal lows
S, C = load(17); bg, d = new(); setup(C, 18, 99.4, 107.8, upto=17)
hl(d, 2.4, 17.4, 102.0, GOLD, 7, True); candles(d)
for i in (3, 7): ring(d, B.X(i), B.Y(102.0), 30, GOLD, 1, 6)
bigarrow(d, B.X(13.0), B.Y(105.6), B.X(15.6), B.Y(101.4), RED)
tag(d, B.X(15.0), B.Y(100.3), "TAKE PROFIT", GREEN, 52)
word(d, 540, 380, "EQUAL LOWS", INK, 135); brand(d); save(bg, 17)
# ---- 18 killzones
S, C = load(18); bg, d = new(); setup(C, 28, 100.6, 111.6, box=(40, 1040, 640, 1480))
for i0, i1, col in ((-0.45, 8.45, INK), (8.55, 15.45, GOLD), (17.55, 23.45, GREEN)):
    d.rounded_rectangle(sc([B.X(i0), B.Y(110.4), B.X(i1), B.Y(101.6)]), radius=14*SS, fill=rgba(col, 0.13))
candles(d)
tag(d, B.X(4), B.Y(110.0), "ASIA", INK, 44); tag(d, B.X(12), B.Y(110.0), "LONDON", GOLD, 44); tag(d, B.X(20.5), B.Y(110.0), "NY", GREEN, 44)
word(d, 540, 400, "KILLZONES", GOLD, 150); tag(d, 540, 1640, "when gold actually moves", INK, 52); brand(d); save(bg, 18)
# ---- 19 entry model
S, C = load(19); bg, d = new(); setup(C, 19, 100.8, 111.8)
zone(d, 11.4, 18.6, 105.2, 106.4, GOLD, 0.25); candles(d)
for n, i, p in ((1, 10, 101.3), (2, 12.6, 108.2), (3, 18.2, 104.4), (4, 15, 104.4)):
    x, y = B.X(i), B.Y(p); d.ellipse(sc([x-42, y-42, x+42, y+42]), fill=INK, outline=WHITE, width=int(5*SS))
    d.text(sc((x, y+2)), str(n), font=font(POP_B, 54), fill=GOLD, anchor="mm")
word(d, 540, 380, "4 STEPS", INK, 170); tag(d, 540, 1640, "my full entry model", GOLD, 56); brand(d); save(bg, 19)
print("ok")
