from common import *
C = [(104.6,105.3,104.2,105.0),(105.0,105.6,104.7,105.4),(105.4,105.7,104.8,104.9),(104.9,105.2,104.3,104.5),(104.5,105.1,104.2,105.0),
     (105.0,105.8,104.8,105.6),(105.6,106.0,105.0,105.2),(105.2,105.5,104.6,104.8),(104.8,105.3,104.5,105.1),(105.1,105.9,104.9,105.7),
     (106.4,107.2,106.2,107.0),(107.0,108.0,106.8,107.8),(107.8,108.9,107.6,108.7),(108.7,109.6,108.4,109.3),(109.3,109.8,108.6,108.8),
     (108.8,109.0,107.6,107.8),(107.8,108.3,107.4,108.0),(108.0,108.1,106.6,106.8),(106.8,107.0,105.7,105.9),(105.9,106.1,104.9,105.2)]
FVG_OK = list(range(20))
NS, PMIN, PMAX = 21, 102.6, 111.0
EV = dict(things="things", one=("one|1",1), two=("two|2",0), three=("three|3",1), naked=("naked",1),
          here="here", poc2=("poc",1), plus="plus", end="comment")
APPEAR = [(0,10,None),(10,15,"two","two+1.2"),(15,20,"here","poc2")]
VPB = [(103.5,1.2),(104.0,2.6),(104.5,4.0),(105.0,6.0),(105.5,4.2),(106.0,2.2),(106.5,0.9)]
ITEMS = [
 dict(k="vp", i=-0.45, bins=VPB, poc=105.0, va=(104.5,105.5), h=0.5, a="one", b="end"),
 dict(k="label", i=4.5, p=107.1, text="yesterday", col=MUTED, size=24, a="one", b="end"),
 dict(k="hline", i0=-0.4, i1=20.4, p=105.0, col=GOLD, a="one", b="end"),
 dict(k="label", i=7.2, p=103.6, text="POC", col=GOLD, a="one", b="two"),
 dict(k="label", i=14.6, p=104.3, text="naked POC", col=GOLD, a="naked", b="end"),
 dict(k="arrow", i0=12.0, p0=106.4, i1=12.0, p1=105.3, col=GOLD, a="two", b="three"),
 dict(k="label", i=12.0, p=106.9, text="never tested", col=INK, size=22, a="two", b="three"),
 dict(k="box", i0=14.6, i1=20.4, p0=105.1, p1=108.6, col=GREEN, fill=0.08, a="three", b="here"),
 dict(k="label", i=17.5, p=110.0, text="clear path", col=GREEN, a="three", b="here"),
 dict(k="hline", i0=15.0, i1=20.4, p=107.6, col=INK, a="here", b="end"),
 dict(k="label", i=16.2, p=106.9, text="sell", col=INK, size=22, a="here", b="end"),
 dict(k="hline", i0=15.0, i1=20.4, p=109.9, col=RED, a="here", b="end"),
 dict(k="label", i=17.0, p=110.4, text="stop", col=RED, size=22, a="here", b="end"),
 dict(k="arrow", i0=15.6, p0=107.3, i1=18.6, p1=105.4, col=RED, a="here+0.4", b="end"),
 dict(k="ring", i=19, p=105.0, r=26, col=GREEN, a="poc2", b="end"),
]
HEAD = [(0, [])]
KEY = {"naked":GOLD,"poc":GOLD,"magnet":GOLD,"control":GOLD,"volume":GOLD,"never":RED,"clear":GREEN,"path":GREEN,"plus":GREEN,"sma":GOLD}
TRACK = dict(labels=["prior POC","untested","clear path"], ev=["one","two","three"], tag="XAUUSD · 15M")
RESULT = dict(text="+2R", a="plus")
CAM = [(0.06,0.7,1.45,5.0,105.2),("one-0.2",0.6,1.3,4.0,105.0),("two-0.2",0.6,1.12,12.0,106.6),("three-0.2",0.6,1.15,17.0,107.0),
       ("here-0.3",0.6,1.1,15.5,107.0),("plus-0.3",0.6,1.0,None,None)]
SFX = [("pop","one"),("pop","two"),("pop","three"),("pop","naked"),("impact","here"),("ding","poc2"),("impact","plus")]
END = dict(save=True, sub="I'll DM you my free guide")
FIX = {"are": "R"}
