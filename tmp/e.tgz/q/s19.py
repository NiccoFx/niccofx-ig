from common import *
C = [(109.6,110.2,108.6,108.9),(108.9,109.2,107.3,107.6),(107.6,108.0,106.0,106.3),(106.3,106.8,104.8,105.1),(105.1,105.4,103.6,103.9),
     (103.9,104.4,103.0,104.1),(104.1,105.1,103.8,104.8),(104.8,105.5,104.3,104.5),(104.5,104.8,103.6,103.8),(103.8,104.0,103.1,103.3),
     (103.3,103.7,102.2,103.6),(103.6,105.2,103.4,105.0),(105.0,107.2,104.9,106.9),(106.9,107.9,106.4,107.6),(107.6,107.8,106.9,107.1),
     (107.1,107.3,106.0,106.3),(106.3,107.9,106.1,107.7),(107.7,109.3,107.4,109.0),(109.0,110.6,108.7,110.4)]
FVG_OK = [11]
NS, PMIN, PMAX = 20, 100.8, 111.8
EV = dict(end="follow", model=("model",0), step0=("step",0), step1=("step",1), step2=("step",2), step3=("step",3), takes="takes",
          change="change", breaks="breaks", fair="fair", gap1=("gap",1), wait="wait", buy="buy", stop="stop", target="target",
          sweep2=("sweep",2), save="save")
APPEAR = [(0,9,None),(9,10,"step0"),(10,11,"takes"),(11,12,"change"),(12,13,"breaks"),(13,14,"fair"),(14,16,"wait","buy"),(16,19,"target","sweep2")]
ITEMS = [
 dict(k="badge", i=0.6, p=111.3, n=1, text="sweep", col=INK, a="step0", b="end"),
 dict(k="badge", i=5.0, p=111.3, n=2, text="shift", col=INK, a="step1", b="end"),
 dict(k="badge", i=9.4, p=111.3, n=3, text="FVG", col=GOLD, a="step2", b="end"),
 dict(k="badge", i=13.4, p=111.3, n=4, text="entry", col=GREEN, a="step3", b="end"),
 dict(k="hline", i0=4.6, i1=11.0, p=103.0, col=INK, text="previous low", a="step0", b="change"),
 dict(k="ring", i=10, p=102.2, r=20, col=RED, a="takes", b="end"),
 dict(k="label", i=10, p=101.5, text="sweep", col=RED, a="takes", b="stop"),
 dict(k="hline", i0=6.6, i1=13.4, p=105.5, col=GREEN, text="CHoCH", bold=True, a="breaks", b="wait"),
 dict(k="box", i0=11.4, i1=19.4, p0=105.2, p1=106.4, col=GOLD, fill=0.2, a="gap1", b="end"),
 dict(k="label", i=17.8, p=105.8, text="FVG", col=GOLD, a="gap1", b="end"),
 dict(k="ring", i=15, p=106.0, r=22, col=GOLD, a="buy", b="end"),
 dict(k="label", i=15, p=104.6, text="buy", col=GOLD, a="buy", b="end"),
 dict(k="hline", i0=9.4, i1=18.4, p=101.9, col=RED, text="stop", bold=True, a="stop", b="end"),
 dict(k="hline", i0=-0.4, i1=18.4, p=110.2, col=GREEN, text="target", bold=True, a="target", b="end"),
 dict(k="arrow", i0=16, p0=107.2, i1=18.4, p1=109.9, col=GREEN, a="target", b="end"),
]
HEAD = [(0,[("my full ",INK),("entry model.",GOLD)]),
        ("step0-0.1",[("1. ",GOLD),("liquidity sweep.",INK)]),
        ("step1-0.1",[("2. ",GOLD),("change of character.",INK)]),
        ("step2-0.1",[("3. ",GOLD),("fair value gap.",INK)]),
        ("step3-0.1",[("4. ",GOLD),("entry in the gap.",INK)]),
        ("stop-0.1",[("stop below ",RED),("the sweep.",INK)]),
        ("target-0.1",[("target ",GREEN),("the liquidity.",INK)]),
        ("sweep2-0.1",[("sweep. shift. ",INK),("gap. entry.",GOLD)]),
        ("end-0.1",[])]
KEY = {"liquidity":GOLD,"sweep":RED,"change":GREEN,"character":GREEN,"breaks":GREEN,"fair":GOLD,"gap":GOLD,"entry":GOLD,"buy":GOLD,
       "stop":RED,"target":GREEN,"shift":GREEN,"save":GOLD,"model":GOLD}
CAM = [(0.06,0.7,1.15,None,105.6),("step0-0.3",0.6,1.25,8.5,105.6),("fair-0.3",0.6,1.12,None,105.8),("target-0.3",0.6,1.0,None,None)]
SFX = [("pop","step0"),("pop","takes"),("pop","step1"),("impact","breaks"),("pop","step2"),("pop","step3"),("impact","buy"),("ding","target")]
END = dict(l1="sweep. shift.", c1=INK, l2="gap. entry.", c2=GOLD, sub="save this and practice it")
