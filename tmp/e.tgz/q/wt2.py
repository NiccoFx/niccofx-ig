import sys, json
from faster_whisper import WhisperModel
m = WhisperModel("base.en", device="cpu", compute_type="int8")
segs, _ = m.transcribe(sys.argv[1], word_timestamps=True)
out = [[w.word.strip(), round(w.start, 2), round(w.end, 2)] for s in segs for w in s.words]
open(sys.argv[2], "w").write(json.dumps(out)); print("words", len(out), out[-1][2] if out else 0)
