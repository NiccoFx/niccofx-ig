from common import *
C = [(106.0,106.5,105.2,105.4),(105.4,105.9,104.9,105.7),(105.7,106.0,105.0,105.2),(105.2,106.3,105.0,106.1),(106.1,106.4,105.1,105.3),
     (105.3,105.5,104.2,104.4),(104.4,104.7,103.4,103.6),(103.6,103.9,102.7,102.9),(102.9,103.4,102.6,103.2),(103.2,103.4,102.5,102.7),
     (102.7,103.5,102.6,103.3),(103.3,103.4,102.6,102.8),(102.8,102.9,101.9,102.3),(102.3,103.6,102.2,103.5),(103.5,104.8,103.3,104.6),
     (104.6,106.0,104.4,105.8),(105.8,107.1,105.6,106.9)]
NS, PMIN, PMAX = 18, 100.6, 108.2
EV = dict(end="follow", swallows="swallows", location="location", middle="middle", nothing="nothing", watch="watch", zone="zone",
          sweeps="sweeps", engulfs="engulfs", signal="signal", buy="buy", stop="stop", target="target", pattern="pattern")
APPEAR = [(0,4,None),(4,5,"nothing"),(5,10,"watch","zone"),(10,12,"zone+0.2","sweeps-0.2"),(12,13,"sweeps"),(13,14,"engulfs"),(14,17,"target","pattern")]
ITEMS = [
 dict(k="box", i0=1.55, i1=3.45, p0=104.85, p1=106.45, col=GOLD, fill=0.08, a="swallows", b="middle"),
 dict(k="label", i=2.5, p=107.1, text="engulfing", col=GOLD, a="swallows", b="middle"),
 dict(k="box", i0=1.55, i1=3.45, p0=104.85, p1=106.45, col=RED, fill=0.08, a="middle", b="watch"),
 dict(k="label", i=2.5, p=107.1, text="middle of nowhere", col=RED, a="middle", b="watch"),
 dict(k="xs", pts=[(4.0,104.6)], col=RED, a="nothing", b="watch"),
 dict(k="box", i0=8.5, i1=17.4, p0=102.3, p1=102.9, col=GREEN, fill=0.15, a="zone", b="end"),
 dict(k="label", i=15.6, p=101.6, text="key support", col=GREEN, a="zone", b="end"),
 dict(k="ring", i=12, p=101.9, r=20, col=RED, a="sweeps", b="end"),
 dict(k="label", i=10.4, p=101.3, text="sweep", col=RED, a="sweeps", b="buy"),
 dict(k="box", i0=11.55, i1=13.45, p0=101.8, p1=103.75, col=GOLD, fill=0.1, a="engulfs", b="end"),
 dict(k="label", i=10.6, p=104.5, text="real engulfing", col=GOLD, a="engulfs", b="end"),
 dict(k="hline", i0=13.0, i1=17.4, p=103.7, col=GOLD, a="buy", b="end"),
 dict(k="label", i=16.6, p=103.1, text="buy", col=GOLD, size=22, a="buy", b="end"),
 dict(k="hline", i0=11.5, i1=17.4, p=101.7, col=RED, a="stop", b="end"),
 dict(k="label", i=14.2, p=101.1, text="stop", col=RED, size=22, a="stop", b="end"),
 dict(k="hline", i0=3.5, i1=17.4, p=106.5, col=GREEN, a="target", b="end"),
 dict(k="label", i=9.0, p=107.1, text="target", col=GREEN, size=22, a="target", b="end"),
]
HEAD = [(0,[("most traders ",INK),("lose here.",RED)]),
        ("swallows-0.3",[("swallows ",GOLD),("the last body.",INK)]),
        ("location-0.2",[("location ",GOLD),("is everything.",INK)]),
        ("middle-0.3",[("in the middle? ",INK),("nothing.",RED)]),
        ("watch-0.1",[("at a ",INK),("key zone.",GREEN)]),
        ("engulfs-0.4",[("that's a ",INK),("real signal.",GREEN)]),
        ("buy-0.1",[("buy above ",GREEN),("the high.",INK)]),
        ("pattern-0.1",[("pattern + ",INK),("location.",GOLD)]),
        ("end-0.1",[])]
KEY = {"engulfing":GOLD,"swallows":GOLD,"location":GOLD,"middle":RED,"nothing":RED,"zone":GREEN,"sweeps":RED,"engulfs":GOLD,
       "signal":GREEN,"buy":GREEN,"stop":RED,"target":GREEN,"pattern":GOLD,"edge":GOLD,"lose":RED}
CAM = [(0.06,0.7,1.15,None,104.5),("middle-0.4",0.6,1.3,3.5,105.4),("watch-0.3",0.6,1.2,12.0,103.6),("pattern-0.3",0.6,1.0,None,None)]
SFX = [("pop","swallows"),("pop","location"),("pop","nothing"),("pop","zone"),("pop","sweeps"),("impact","engulfs"),("pop","stop"),("ding","target")]
END = dict(l1="pattern + location.", c1=INK, l2="that's the edge.", c2=GOLD, sub="save this for your next trade")
