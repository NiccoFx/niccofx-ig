import sys, math, importlib
sys.argv = ["x"]
import r8 as B
from r8 import *
from PIL import Image, ImageDraw
WHITE = (250, 250, 248)
def load(n):
    S = importlib.import_module(f"s{n}")
    C = [list(c) for c in getattr(S, "C", [])]
    ok = set(getattr(S, "FVG_OK", []))
    for i in range(len(C) - 2):
        if i in ok: continue
        if C[i+2][2] > C[i][1]: C[i+2][2] = round(C[i][1] - 0.15, 2)
        if C[i+2][1] < C[i][3] and C[i+2][1] < C[i][2]: C[i+2][1] = round(C[i][2] + 0.15, 2)
    return S, [tuple(c) for c in C]
def setup(C, ns, pmin, pmax, box=(70, 1010, 640, 1480), upto=None):
    B.C = C[:upto] if upto else C; B.N = len(B.C); B.NS = ns
    B.CX0, B.CX1, B.CY0, B.CY1 = box; B.PMIN, B.PMAX = pmin, pmax
def bigarrow(d, x0, y0, x1, y1, col, w=30, head=70):
    ang = math.atan2(y1 - y0, x1 - x0); ca, sa = math.cos(ang), math.sin(ang)
    bx, by = x1 - head * ca, y1 - head * sa
    nx, ny = -sa, ca
    pts = [(x0 + nx*w/2, y0 + ny*w/2), (bx + nx*w/2, by + ny*w/2), (bx + nx*head*0.75, by + ny*head*0.75), (x1, y1),
           (bx - nx*head*0.75, by - ny*head*0.75), (bx - nx*w/2, by - ny*w/2), (x0 - nx*w/2, y0 - ny*w/2)]
    d.polygon([sc(p) for p in pts], fill=col, outline=INK, width=int(5*SS))
def word(d, x, y, s, col, size=150, stroke=8, anchor="mm"):
    d.text(sc((x, y)), s, font=font(POP_B, size), fill=col, anchor=anchor, stroke_width=int(stroke*SS), stroke_fill=WHITE)
def tag(d, x, y, s, col, size=64):
    f = font(POP_B, size); tw = d.textlength(s, font=f) / SS
    d.rounded_rectangle(sc([x - tw/2 - 28, y - size*0.72, x + tw/2 + 28, y + size*0.72]), radius=22*SS, fill=col)
    d.text(sc((x, y + 2)), s, font=f, fill=WHITE, anchor="mm")
def zone(d, i0, i1, p0, p1, col, a=0.22):
    d.rounded_rectangle(sc([B.X(i0), B.Y(p1), B.X(i1), B.Y(p0)]), radius=12*SS, fill=rgba(col, a), outline=rgba(col, 1), width=int(5*SS))
def hl(d, i0, i1, p, col, w=6, dash=False):
    if dash: dashed(d, B.X(i0), B.Y(p), B.X(i1), col, 1, w=w, dash=26, gap=16)
    else: d.line(sc([B.X(i0), B.Y(p), B.X(i1), B.Y(p)]), fill=col, width=int(w*SS))
def candles(d):
    for i in range(B.N): B.candle(d, i)
def brand(d):
    d.ellipse(sc([60, 92, 76, 108]), fill=GOLD); d.text(sc((88, 100)), "NiccoFX", font=font(POP_B, 32), fill=INK, anchor="lm")
def new():
    bg = B.make_bg(); return bg, ImageDraw.Draw(bg, "RGBA")
def save(bg, n):
    bg.resize((W, H), Image.LANCZOS).save(f"covers/cover{n}.jpg", quality=92)

# ---- 20 S/R flip
S, C = load(20); bg, d = new(); setup(C, 23, 97.8, 107.6)
hl(d, -0.4, 13.6, 103.0, GREEN, 7, True); hl(d, 13.6, 22.4, 103.0, RED, 7, True); candles(d)
for i in (3, 7, 11): ring(d, B.X(i), B.Y(103.0), 28, GREEN, 1, 6)
ring(d, B.X(18), B.Y(103.0), 34, GOLD, 1, 7)
bigarrow(d, B.X(21.6), B.Y(107.0), B.X(18.7), B.Y(103.8), RED, 26, 60)
word(d, 540, 400, "S/R FLIP", INK, 170); tag(d, 540, 1660, "sell the retest", RED, 58); brand(d); save(bg, 20)
# ---- 21 POC
S, C = load(21); bg, d = new(); setup(C, 26, 100.8, 110.0)
d.rounded_rectangle(sc([B.X(-0.4), B.Y(105.0), B.X(21.2), B.Y(103.0)]), radius=12*SS, fill=rgba(GOLD, 0.12))
for pp, L in S.BINS:
    c, al = (GOLD, 1.0) if pp == 104.0 else ((GOLD, 0.5) if 103 <= pp <= 105 else (INK, 0.25))
    d.rounded_rectangle(sc([B.X(21.4), B.Y(pp + 0.22), B.X(21.4) + L * B.STEP(), B.Y(pp - 0.22)]), radius=5*SS, fill=rgba(c, al))
hl(d, -0.4, 21.3, 104.0, GOLD, 7, True); candles(d)
bigarrow(d, B.X(16.0), B.Y(108.6), B.X(18.2), B.Y(104.8), GOLD, 26, 60)
word(d, 540, 400, "POC", GOLD, 200); tag(d, 540, 1660, "the price magnet", INK, 58); brand(d); save(bg, 21)
# ---- 22 engulfing
S, C = load(22); bg, d = new(); setup(C, 18, 100.6, 108.2)
zone(d, 8.5, 17.4, 102.3, 102.9, GREEN, 0.2); candles(d)
d.rounded_rectangle(sc([B.X(11.5), B.Y(103.85), B.X(13.5), B.Y(101.7)]), radius=12*SS, outline=GOLD, width=int(6*SS))
bigarrow(d, B.X(7.6), B.Y(99.9), B.X(11.3), B.Y(101.7), GREEN, 26, 60)
word(d, 540, 400, "ENGULFING", INK, 140); tag(d, 540, 1660, "location is everything", GOLD, 54); brand(d); save(bg, 22)
# ---- 23 value area
S, C = load(23); bg, d = new(); setup(C, 19, 99.6, 108.8)
d.rounded_rectangle(sc([B.X(-0.4), B.Y(106.0), B.X(14.2), B.Y(102.0)]), radius=12*SS, fill=rgba(GOLD, 0.14))
for pp, L in S.BINS:
    c, al = (GOLD, 1.0) if pp == 104.0 else ((GOLD, 0.5) if 102 <= pp <= 106 else (INK, 0.25))
    d.rounded_rectangle(sc([B.X(14.4), B.Y(pp + 0.2), B.X(14.4) + L * B.STEP(), B.Y(pp - 0.2)]), radius=5*SS, fill=rgba(c, al))
hl(d, -0.4, 14.2, 106.0, RED, 7, True); hl(d, -0.4, 14.2, 102.0, GREEN, 7, True); candles(d)
tag(d, B.X(1.2), B.Y(106.0) - 60, "VAH", RED, 44); tag(d, B.X(1.2), B.Y(102.0) + 60, "VAL", GREEN, 44)
word(d, 540, 360, "VALUE", GOLD, 170); word(d, 540, 530, "AREA", INK, 150); tag(d, 540, 1660, "trade the edges", INK, 58); brand(d); save(bg, 23)
# ---- 24 pin bar
S, C = load(24); bg, d = new(); setup(C, 15, 102.0, 110.2, upto=13)
hl(d, -0.4, 14.4, 108.0, RED, 7, True); candles(d)
d.rounded_rectangle(sc([B.X(11.55), B.Y(108.95), B.X(12.45), B.Y(106.75)]), radius=12*SS, outline=GOLD, width=int(6*SS))
bigarrow(d, B.X(14.4), B.Y(110.4), B.X(12.7), B.Y(108.3), GOLD, 26, 60)
tag(d, B.X(13.6), B.Y(106.2), "REJECTED", RED, 40)
word(d, 540, 400, "PIN BAR", RED, 170); tag(d, 540, 1660, "only at key levels", INK, 58); brand(d); save(bg, 24)
print("ok")
