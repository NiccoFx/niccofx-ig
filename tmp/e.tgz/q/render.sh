set -e
N=$1; cd /home/user/q/r$N
python3 ../q.py s$N words.json x.mp4 --events events.json
DUR=$(python3 -c "import json;print(json.load(open('events.json'))['dur'])")
python3 ../music.py $DUR events.json music.wav sfx.wav
python3 ../q.py s$N words.json silent.mp4
ffmpeg -v error -y -i silent.mp4 -i vo_q.wav -i music.wav -i sfx.wav -filter_complex "[1]asplit=2[v1][v2];[2]volume=0.24[m];[m][v2]sidechaincompress=threshold=0.04:ratio=5:attack=8:release=280[md];[3]volume=0.42[s];[v1][md][s]amix=inputs=3:normalize=0:duration=longest,loudnorm=I=-14:TP=-1.5:LRA=9[a]" -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -ar 48000 -shortest -movflags +faststart reel$N.mp4
ffprobe -v error -show_entries format=duration -of csv=p=0 reel$N.mp4
