from common import *
C = []
NS, PMIN, PMAX = 25, 0.0, 20.0
EV = dict(CD, eight=("eight|8",0), four=("four|4",0), who="who", ans="after:n1", reason="reason", size="size", look="look",
          risks0=("risks",0), wins2=("wins",2), losses0=("losses",0), down="down", risks1=("risks",1), wins3=("wins",3),
          losses1=("losses",1), upv=("up",0), takes="takes", opposite="opposite", so=("so",0))
APPEAR = []
RING = (12, 12.5)
ITEMS = [
 dict(k="label", i=5.5, p=18.6, text="TRADER A", col=INK, size=34, a=0.05),
 dict(k="label", i=18.5, p=18.6, text="TRADER B", col=INK, size=34, a="four-1.0"),
 dict(k="label", i=5.5, p=17.0, text="80% win rate", col=GOLD, size=28, a="eight"),
 dict(k="label", i=18.5, p=17.0, text="40% win rate", col=GOLD, size=28, a="four"),
 dict(k="box", i0=13.0, i1=24.0, p0=16.1, p1=19.5, col=GREEN, fill=0.08, a="ans", b="takes-0.3"),
 # A trade
 dict(k="box", i0=1.0, i1=10.0, p0=10.0, p1=11.0, col=GREEN, fill=0.35, a="risks0+0.6"),
 dict(k="box", i0=1.0, i1=10.0, p0=5.0, p1=10.0, col=RED, fill=0.30, a="risks0"),
 dict(k="hline", i0=0.6, i1=10.4, p=10.0, col=INK, dash=False, a="risks0"),
 dict(k="label", i=5.5, p=11.9, text="+20", col=GREEN, size=30, a="risks0+0.6"),
 dict(k="label", i=5.5, p=7.5, text="-100", col=RED, size=30, a="risks0"),
 dict(k="label", i=5.5, p=3.7, text="8 wins  +160", col=GREEN, a="wins2"),
 dict(k="label", i=5.5, p=2.4, text="2 losses  -200", col=RED, a="losses0"),
 dict(k="label", i=5.5, p=0.9, text="= -40", col=RED, size=40, a="down"),
 # B trade
 dict(k="box", i0=14.0, i1=23.0, p0=10.0, p1=14.5, col=GREEN, fill=0.35, a="risks1+0.6"),
 dict(k="box", i0=14.0, i1=23.0, p0=8.5, p1=10.0, col=RED, fill=0.30, a="risks1"),
 dict(k="hline", i0=13.6, i1=23.4, p=10.0, col=INK, dash=False, a="risks1"),
 dict(k="label", i=18.5, p=12.25, text="+300", col=GREEN, size=30, a="risks1+0.6"),
 dict(k="label", i=18.5, p=9.25, text="-100", col=RED, size=30, a="risks1"),
 dict(k="label", i=18.5, p=3.7, text="4 wins  +1200", col=GREEN, a="wins3"),
 dict(k="label", i=18.5, p=2.4, text="6 losses  -600", col=RED, a="losses1"),
 dict(k="label", i=18.5, p=0.9, text="= +600", col=GREEN, size=40, a="upv"),
]
CMP = dict(a="takes", b="so", cards=[
 dict(title="TRADER A", col=RED, t="takes", tsize=46, bars=[(60, GREEN, "wins"), (-200, RED, "losses")], base=930,
      mark="x", l1="small wins", l2="big losses"),
 dict(title="TRADER B", col=GREEN, t="opposite", tsize=46, bars=[(200, GREEN, "wins"), (-60, RED, "losses")], base=1010,
      mark="check", l1="small losses", l2="big wins")])
HEAD = [(0,[("80% ",GOLD),("vs ",INK),("40% wins.",GOLD)]),
        ("who-0.1",[("who makes ",INK),("more money?",GOLD)]),
        ("ans-0.05",[("trader B.",GREEN)]),
        ("reason-0.1",[("it's the ",INK),("size.",GOLD)]),
        ("risks0-0.2",[("A risks ",INK),("100 for 20.",RED)]),
        ("risks1-0.2",[("B risks ",INK),("100 for 300.",GREEN)]),
        ("takes-0.1",[("small wins ",RED),("vs ",INK),("big wins.",GREEN)]),
        ("so-0.1",[("chase ",INK),("reward to risk.",GOLD)]),
        ("end-0.1",[])]
KEY = {"b":GREEN,"size":GOLD,"down":RED,"up":GREEN,"losses":RED,"wins":GREEN,"opposite":GREEN,"reward":GOLD,"risk":GOLD,
       "money":GOLD,"risks":GOLD}
CAM = [(0.06,0.7,1.25,12,15.5),("risks0-0.3",0.6,1.22,5.5,9.0),("risks1-0.3",0.6,1.22,18.5,9.0),("takes-0.4",0.5,1.0,None,None)]
SFX = [("pop","eight"),("pop","four"),("pop","wins2"),("pop","losses0"),("impact","down"),("pop","wins3"),("pop","losses1"),("ding","upv")]
END = dict(l1="stop chasing", c1=INK, l2="win rate.", c2=GOLD, sub="chase reward to risk")
