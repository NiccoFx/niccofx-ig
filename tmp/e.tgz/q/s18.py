from common import *
C = [(104.0,104.5,103.7,104.3),(104.3,104.6,103.9,104.0),(104.0,104.4,103.6,104.2),(104.2,104.5,103.8,103.9),(103.9,104.3,103.6,104.1),
     (104.1,104.6,103.9,104.4),(104.4,104.5,103.8,103.9),(103.9,104.3,103.7,104.2),(104.2,104.4,103.8,104.0),
     (104.0,104.1,102.8,103.0),(103.0,104.3,102.7,104.1),(104.1,105.8,103.9,105.6),(105.6,107.0,105.3,106.8),(106.8,107.4,106.2,106.5),
     (106.5,107.9,106.3,107.6),(107.6,108.0,107.0,107.3),(107.3,107.6,106.8,107.0),(107.0,107.4,106.7,107.2),
     (107.2,107.3,106.2,106.4),(106.4,108.2,106.2,108.0),(108.0,109.4,107.8,109.1),(109.1,109.6,108.6,108.9),(108.9,109.3,108.0,108.2),
     (108.2,108.6,107.6,107.9),(107.9,108.3,107.6,108.1),(108.1,108.3,107.7,107.8),(107.8,108.2,107.5,108.0),(108.0,108.2,107.6,107.7)]
NS, PMIN, PMAX = 29, 100.6, 111.6
EV = dict(end="follow", hours="hours", asian=("asian",0), range_=("range",0), noise="noise", london=("london",0), floods="floods",
          first="first", sweep="sweep", york=("york",0), second="second", continues="continues", outside="outside", chops="chops",
          overtrade="overtrade", trade=("trade",0), rest="rest")
APPEAR = [(0,28,None)]
UNDER = [
 dict(k="box", i0=-0.45, i1=8.45, p0=101.0, p1=110.9, col=INK, fill=0.06, line=False, a="asian", b="end"),
 dict(k="box", i0=8.55, i1=15.45, p0=101.0, p1=110.9, col=GOLD, fill=0.13, line=False, a="london", b="end"),
 dict(k="box", i0=17.55, i1=23.45, p0=101.0, p1=110.9, col=GREEN, fill=0.11, line=False, a="york", b="end"),
 dict(k="box", i0=23.55, i1=28.45, p0=101.0, p1=110.9, col=RED, fill=0.07, line=False, a="outside", b="end"),
]
ITEMS = [
 dict(k="label", i=4, p=110.3, text="ASIA", col=INK, a="asian", b="end"),
 dict(k="label", i=12, p=110.3, text="LONDON", col=GOLD, a="london", b="end"),
 dict(k="label", i=20.5, p=110.3, text="NEW YORK", col=GREEN, a="york", b="end"),
 dict(k="label", i=26, p=110.3, text="CHOP", col=RED, a="outside", b="end"),
 dict(k="box", i0=-0.4, i1=8.4, p0=103.6, p1=104.6, col=INK, fill=0.08, a="range_", b="london"),
 dict(k="label", i=4, p=105.4, text="tight range", col=INK, a="range_", b="london"),
 dict(k="label", i=4, p=102.8, text="low volume · noise", col=MUTED, a="noise", b="london"),
 dict(k="ring", i=9, p=102.8, r=20, col=RED, a="sweep", b="end"),
 dict(k="label", i=9.4, p=101.9, text="asian low swept", col=RED, a="sweep", b="york"),
 dict(k="arrow", i0=10.4, p0=103.6, i1=14.6, p1=108.8, col=GOLD, a="first", b="end"),
 dict(k="label", i=13.0, p=104.4, text="first big move", col=GOLD, a="first", b="york"),
 dict(k="arrow", i0=18.4, p0=106.2, i1=20.6, p1=110.0, col=GREEN, a="continues", b="end"),
 dict(k="label", i=20.5, p=105.2, text="continue or reverse", col=GREEN, a="second", b="outside"),
 dict(k="label", i=26, p=106.2, text="overtrading zone", col=RED, a="overtrade", b="end"),
]
HEAD = [(0,[("gold doesn't move ",INK),("all day.",RED)]),
        ("hours-0.8",[("it moves in ",INK),("key hours.",GOLD)]),
        ("asian-0.1",[("asia: ",INK),("range & noise.",MUTED)]),
        ("london-0.1",[("london: ",GOLD),("the first move.",INK)]),
        ("york-0.3",[("new york: ",GREEN),("wave two.",INK)]),
        ("outside-0.1",[("outside = ",INK),("chop.",RED)]),
        ("trade-0.1",[("trade the ",INK),("killzones.",GOLD)]),
        ("end-0.1",[])]
KEY = {"london":GOLD,"york":GREEN,"asian":INK,"noise":MUTED,"sweep":RED,"chops":RED,"overtrade":RED,"lose":RED,"killzones":GOLD,
       "volume":GOLD,"first":GOLD,"second":GREEN,"rest":GREEN,"floods":GOLD,"range":GOLD}
CAM = [("asian-0.3",0.6,1.3,5.0,105.0),("london-0.3",0.6,1.25,12.0,106.0),("york-0.4",0.6,1.25,20.0,107.6),("outside-0.3",0.6,1.0,None,None)]
SFX = [("pop","range_"),("impact","london"),("pop","sweep"),("whoosh","first"),("impact","york"),("pop","overtrade")]
END = dict(l1="trade the", c1=INK, l2="killzones.", c2=GOLD, sub="rest the other hours")
