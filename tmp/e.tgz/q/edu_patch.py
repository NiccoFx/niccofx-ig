s = open("q.py").read()
R = [
('    ev["end"] = ev.get("end", 999)\n', '    ev["end"] = ev.get("end", 999)\n    ev.setdefault("ans", 999.0); ev.setdefault("decide", 999.0)\n'),
('    if ev["decide"] <= t < ev["ans"] + 0.3:', '    if "decide" in S.EV and ev["decide"] <= t < ev["ans"] + 0.3:'),
('    elif k == "check":', '''    elif k == "badge":
        x, y = X(it["i"]) + it.get("dx", 0), Y(it["p"]) + it.get("dy", 0)
        r = 24 * (1 + 0.25 * (1 - ease((t - T(it.get("a", 0), ev)) / 0.3)))
        d.ellipse(sc([x - r, y - r, x + r, y + r]), fill=rgba(col, a))
        d.text(sc((x, y + 1)), str(it["n"]), font=font(POP_B, 28), fill=rgba((248, 248, 246), a), anchor="mm")
        if it.get("text"): label(d, x + 34, y, it["text"], col, a, it.get("size", 24), anchor="lm")
    elif k == "check":'''),
('    sfx = [["pop", 0.05], ["pop", ev["n3"]], ["pop", ev["n2"]], ["pop", ev["n1"]], ["impact", ev["ans"]]]',
 '    quiz = "decide" in S.EV\n    sfx = [["pop", 0.05]] + ([["pop", ev["n3"]], ["pop", ev["n2"]], ["pop", ev["n1"]], ["impact", ev["ans"]]] if quiz else [["impact", 0.05]])'),
('    json.dump({"break": round(ev["decide"], 2), "resume": round(ev["ans"], 2), "sfx": sfx, "dur": round(end_t + 0.1, 2)}, open(path, "w"))',
 '    out = {"sfx": sfx, "dur": round(end_t + 0.1, 2)}\n    if quiz: out.update({"break": round(ev["decide"], 2), "resume": round(ev["ans"], 2)})\n    json.dump(out, open(path, "w"))'),
('sfx = [[k, round(v, 2)] for k, v in sfx if 0 <= v < 900]', 'sfx = [[k, round(v, 2)] for k, v in sfx if (0.35 if k in ("whoosh", "riser") else 0) <= v < 900]'),
]
for a, b in R:
    assert a in s, a[:60]
    s = s.replace(a, b)
open("q.py", "w").write(s); print("patched")
