#!/usr/bin/env python3
"""NiccoFX v2 quiz reel engine (data-driven). Usage: q.py SPEC words.json out.mp4 [--preview t1,t2] [--events ev.json]"""
import sys, os, math, importlib, json, random
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import r8 as B
from r8 import (ease, eio, fade, sc, rgba, font, POP_B, POP_M, ANT, INK, GREEN, RED, GOLD, MUTED, WICK, BG, W, H, SS, LABEL_BG, DARK,
                dashed, label, ring, arrow, check, norm)
from PIL import ImageDraw

S = importlib.import_module(sys.argv.pop(1))

# ---------- candles + FVG auto-fix ----------
C = [list(c) for c in getattr(S, "C", [])]
OK = set(getattr(S, "FVG_OK", []))
for i in range(len(C) - 2):
    if i in OK: continue
    o1, h1, l1, c1 = C[i]; o3, h3, l3, c3 = C[i + 2]
    if l3 > h1:
        C[i + 2][2] = round(h1 - 0.15, 2); print("fvg-fix bull", i, file=sys.stderr)
    if h3 < l1:
        C[i + 2][1] = round(l1 + 0.15, 2); print("fvg-fix bear", i, file=sys.stderr)
B.C = [tuple(c) for c in C]; B.N = len(C)
B.NS = S.NS; B.PMIN, B.PMAX = S.PMIN, S.PMAX
X, Y = B.X, B.Y

# ---------- words / events ----------
def fix_words(words):
    out = []; i = 0
    rep = getattr(S, "FIX", {})
    while i < len(words):
        w, s, e = words[i]; n = norm(w)
        if (n.startswith("nik") or n.startswith("nic")) and i + 1 < len(words) and norm(words[i + 1][0]) in ("fx", "effects", "x"):
            out.append(["NiccoFX", s, words[i + 1][2]]); i += 2; continue
        if n.startswith("nik") or n.startswith("nic"): w = "NiccoFX"
        if n in rep: w = rep[n] + (w[-1] if w[-1] in ".,?!" else "")
        out.append([w, s, e]); i += 1
    return out

MISSING = []
def schedule(words):
    toks = [norm(w[0]) for w in words]
    ev = {}
    def find(spec):
        if isinstance(spec, str) and spec.startswith("after:"):
            ref = spec[6:]
            t0 = ev.get(ref, 999)
            for w in words:
                if w[1] > t0 + 0.05: return w[1]
            return 999
        tok, occ = (spec, 0) if isinstance(spec, str) else spec
        alts = tok.split("|"); k = 0
        for w, n in zip(words, toks):
            if n in alts:
                if k == occ: return w[1]
                k += 1
        MISSING.append(spec); return 999
    for name, spec in S.EV.items():
        ev[name] = find(spec)
    ev["end"] = ev.get("end", 999)
    ev.setdefault("ans", 999.0); ev.setdefault("decide", 999.0)
    ct = [None] * B.N
    for ap in S.APPEAR:
        i0, i1, a = ap[0], ap[1], ap[2]
        b = ap[3] if len(ap) > 3 else None
        if a is None:
            for i in range(i0, i1): ct[i] = -1.0
            continue
        ta = T(a, ev); tb = T(b, ev) if b is not None else ta + 0.12 * (i1 - i0)
        n = max(1, i1 - i0)
        for k, i in enumerate(range(i0, i1)): ct[i] = ta + k * (tb - ta) / n
    ev["ct"] = ct
    return ev

def T(x, ev):
    if x is None: return 999.0
    if isinstance(x, (int, float)): return float(x)
    for op in ("+", "-"):
        if op in x[1:]:
            j = x.rindex(op)
            return ev.get(x[:j], 999.0) + (float(x[j + 1:]) if op == "+" else -float(x[j + 1:]))
    return ev.get(x, 999.0)

def alpha(t, it, ev):
    a = fade(t, T(it.get("a", 0), ev), it.get("fin", 0.25))
    b = it.get("b")
    if b is not None: a *= 1 - fade(t, T(b, ev), 0.3)
    return a

def xm(d, x, y, col, a, s=10, w=4):
    d.line(sc([x - s, y - s, x + s, y + s]), fill=rgba(col, a), width=int(w * SS))
    d.line(sc([x - s, y + s, x + s, y - s]), fill=rgba(col, a), width=int(w * SS))

def draw_item(d, t, it, ev):
    a = alpha(t, it, ev)
    if a <= 0: return
    k = it["k"]; col = it.get("col", INK)
    if k == "label":
        label(d, X(it["i"]) + it.get("dx", 0), Y(it["p"]) + it.get("dy", 0), it["text"], col, a, it.get("size", 24), bg=it.get("bg", True))
    elif k == "ring":
        ring(d, X(it["i"]), Y(it["p"]), it.get("r", 22), col, a, it.get("w", 4))
    elif k == "box":
        x0, x1 = X(it["i0"]), X(it["i1"]); y0, y1 = Y(it["p1"]), Y(it["p0"])
        d.rounded_rectangle(sc([x0, y0, x1, y1]), radius=10 * SS, fill=rgba(col, it.get("fill", 0.12) * a),
                            outline=rgba(col, a) if it.get("line", True) else None, width=int(3 * SS))
    elif k == "hline":
        x0, x1, y = X(it["i0"]), X(it["i1"]), Y(it["p"])
        if it.get("dash", True): dashed(d, x0, y, x1, col, a * it.get("op", 1.0), w=3)
        else: d.line(sc([x0, y, x1, y]), fill=rgba(col, a), width=int(3 * SS))
        if it.get("text"):
            d.text(sc((x1 + 10, y)), it["text"], font=font(POP_B if it.get("bold") else POP_M, 24), fill=rgba(col if it.get("bold") else MUTED, a), anchor="lm")
    elif k == "vline":
        x = X(it["i"]); yy0, yy1 = Y(it["p1"]), Y(it["p0"]); y = yy0
        while y < yy1:
            d.line(sc([x, y, x, min(y + 14, yy1)]), fill=rgba(col, a), width=int(3 * SS)); y += 24
        if it.get("text"): label(d, x, yy0 - 26, it["text"], col, a, 24)
    elif k == "arrow":
        p = ease((t - T(it.get("a", 0), ev)) / 0.5) if it.get("grow", True) else 1
        x0, y0 = X(it["i0"]), Y(it["p0"]); x1, y1 = X(it["i1"]), Y(it["p1"])
        arrow(d, x0, y0, x0 + (x1 - x0) * p, y0 + (y1 - y0) * p, col, a, w=4)
    elif k == "xs":
        for j, (i, pp) in enumerate(it["pts"]):
            xm(d, X(i), Y(pp), col, a * fade(t, T(it.get("a", 0), ev) + 0.07 * j, 0.12))
    elif k == "vp":
        h = it.get("h", 0.5); poc = it.get("poc"); va = it.get("va", (0, 0)); t0 = T(it.get("a", 0), ev)
        for j, (pp, L) in enumerate(it["bins"]):
            g = ease((t - t0 - 0.025 * j) / 0.5)
            if g <= 0: continue
            x0 = X(it["i"]); x1 = x0 + L * B.STEP() * g
            if poc is not None and abs(pp - poc) < 1e-6: c, al = GOLD, 0.95
            elif va[0] <= pp <= va[1]: c, al = GOLD, 0.45
            else: c, al = INK, 0.22
            d.rounded_rectangle(sc([x0, Y(pp + h * 0.45), max(x1, x0 + 2), Y(pp - h * 0.45)]), radius=4 * SS, fill=rgba(c, al * a))
    elif k == "badge":
        x, y = X(it["i"]) + it.get("dx", 0), Y(it["p"]) + it.get("dy", 0)
        r = 24 * (1 + 0.25 * (1 - ease((t - T(it.get("a", 0), ev)) / 0.3)))
        d.ellipse(sc([x - r, y - r, x + r, y + r]), fill=rgba(col, a))
        d.text(sc((x, y + 1)), str(it["n"]), font=font(POP_B, 28), fill=rgba((248, 248, 246), a), anchor="mm")
        if it.get("text"): label(d, x + 34, y, it["text"], col, a, it.get("size", 24), anchor="lm")
    elif k == "check":
        check(d, X(it["i"]), Y(it["p"]), it.get("s", 16), col, a)
    elif k == "dots":
        rnd = random.Random(it.get("seed", 5))
        for j in range(it.get("n", 10)):
            px = X(it["i0"]) + rnd.random() * (X(it["i1"]) - X(it["i0"]))
            py = Y(it["p0"] + rnd.random() * (it["p1"] - it["p0"]))
            aa = a * fade(t, T(it.get("a", 0), ev) + j * 0.03, 0.12)
            d.ellipse(sc([px - 7, py - 7, px + 7, py + 7]), fill=rgba(col, aa))

def world(t, bg, ev):
    im = bg.copy(); d = ImageDraw.Draw(im, "RGBA")
    for it in getattr(S, "UNDER", []): draw_item(d, t, it, ev)
    for i in range(B.N):
        st = ev["ct"][i]
        if st is None or t < st: continue
        B.candle(d, i, 1.0 if st < 0 else (t - st) / 0.22)
    for it in S.ITEMS: draw_item(d, t, it, ev)
    # countdown
    if "decide" in S.EV and ev["decide"] <= t < ev["ans"] + 0.3:
        ca = fade(t, ev["decide"], 0.25) * (1 - fade(t, ev["ans"], 0.25))
        cx, cy, r = X(S.RING[0]), Y(S.RING[1]), 54
        d.ellipse(sc([cx - r, cy - r, cx + r, cy + r]), fill=rgba((246, 246, 244), 0.92 * ca), outline=rgba(INK, 0.25 * ca), width=int(4 * SS))
        if t >= ev["n3"]:
            prog = max(0.0, min(1.0, (t - ev["n3"]) / max(0.1, ev["ans"] - ev["n3"])))
            d.arc(sc([cx - r, cy - r, cx + r, cy + r]), start=-90, end=-90 + 360 * (1 - prog), fill=rgba(GOLD, ca), width=int(7 * SS))
        num = "?" if t < ev["n3"] else ("3" if t < ev["n2"] else ("2" if t < ev["n1"] else "1"))
        tk = {"3": ev["n3"], "2": ev["n2"], "1": ev["n1"]}.get(num, 0)
        bump = 1 + 0.35 * (1 - ease((t - tk) / 0.25)) if num != "?" else 1
        d.text(sc((cx, cy + 2)), num, font=font(POP_B, int(56 * bump)), fill=rgba(INK, ca), anchor="mm")
        d.text(sc((cx, cy + r + 30)), "decide", font=font(POP_M, 24), fill=rgba(MUTED, ca), anchor="mm")
    cmp = getattr(S, "CMP", None)
    if cmp:
        panel = fade(t, T(cmp["a"], ev) - 0.2, 0.35) * (1 - fade(t, T(cmp["b"], ev) - 0.1, 0.35))
        if panel > 0:
            d.rectangle(sc([0, 470, W, 1430]), fill=rgba(BG, 0.96 * panel))
            draw_compare(d, t, ev, panel, cmp)
    return im

def draw_compare(d, t, ev, a, cmp):
    bw = 40
    for ci, cd in enumerate(cmp["cards"]):
        x0, x1 = (60, 520) if ci == 0 else (560, 1020)
        t0 = T(cd["t"], ev); col = cd["col"]
        ca = fade(t, t0, 0.3) * a
        if ca <= 0: continue
        y0, y1 = 520, 1400
        mid = (x0 + x1) / 2
        d.rounded_rectangle(sc([x0, y0, x1, y1]), radius=28 * SS, fill=rgba((244, 244, 242), 0.95 * ca), outline=rgba(col, ca), width=int(3 * SS))
        d.text(sc((mid, y0 + 70)), cd["title"], font=font(POP_B, cd.get("tsize", 52)), fill=rgba(col, ca), anchor="mm")
        seq = cd.get("seq", [])
        n = len(seq)
        def cx(k): return mid - (n - 1) * 30 + k * 60
        if cd.get("level"):
            dashed(d, x0 + 40, cd["level"], x1 - 40, INK, 0.6 * ca, w=3)
        if cd.get("zone"):
            k0, y_a, y_b, zc = cd["zone"]
            d.rounded_rectangle(sc([cx(k0) - 30, y_a, x1 - 40, y_b]), radius=8 * SS, fill=rgba(zc, 0.15 * ca), outline=rgba(zc, ca), width=int(2 * SS))
        for k, (o, h, l, c) in enumerate(seq):
            prog = (t - t0 - 0.15 - k * 0.12) / 0.2
            if prog <= 0: continue
            p = ease(prog)
            cc = o + (c - o) * p
            hh = max(o, cc) - (max(o, cc) - h) * p
            ll = min(o, cc) + (l - min(o, cc)) * p
            colc = GREEN if c < o else RED
            d.line(sc([cx(k), hh, cx(k), ll]), fill=rgba(WICK, ca), width=int(3 * SS))
            top, bot = min(o, cc), max(o, cc)
            d.rounded_rectangle(sc([cx(k) - bw / 2, top, cx(k) + bw / 2, max(bot, top + 3)]), radius=5 * SS, fill=rgba(colc, ca))
        bars = cd.get("bars", [])
        for k, (v, bc, bt) in enumerate(bars):
            bk = ease((t - t0 - 0.2 - k * 0.2) / 0.35)
            if bk <= 0: continue
            bx = mid - 75 + k * 150; base = cd.get("base", 960)
            yy = base - v * bk
            d.rounded_rectangle(sc([bx - 48, min(base, yy), bx + 48, max(base, yy)]), radius=8 * SS, fill=rgba(bc, ca))
            d.text(sc((bx, yy - 28 if v > 0 else yy + 28)), bt, font=font(POP_B, 28), fill=rgba(bc, ca * bk), anchor="mm")
        if bars:
            d.line(sc([x0 + 40, cd.get("base", 960), x1 - 40, cd.get("base", 960)]), fill=rgba(INK, 0.5 * ca), width=int(2 * SS))
        if cd.get("buy"):
            k, by = cd["buy"]
            bk = fade(t, t0 + 0.15 + k * 0.12 + 0.2, 0.2) * ca
            d.ellipse(sc([cx(k) - 12, by - 12, cx(k) + 12, by + 12]), fill=rgba(GOLD, bk))
        nd = max(n, len(bars) * 2)
        done = fade(t, t0 + 0.15 + nd * 0.12 + 0.25, 0.2) * ca
        mx, my = cd.get("mark_at", (150, 660))
        if done > 0:
            if cd.get("mark") == "x": xm(d, mid + mx, my, RED, done, 14, 5)
            elif cd.get("mark") == "check": check(d, mid + mx, my, 18, GREEN, done)
        d.text(sc((mid, y1 - 150)), cd["l1"], font=font(POP_B, 38), fill=rgba(INK, ca), anchor="mm")
        d.text(sc((mid, y1 - 100)), cd["l2"], font=font(POP_B, 38), fill=rgba(col, ca), anchor="mm")

def camera(t, ev):
    keys = [(0.0, 0.01, 1.14, 540, 900), (0.05, 0.6, 1.0, 540, 960)]
    for (e, dur, s, i, p) in S.CAM:
        keys.append((T(e, ev), dur, s, 540 if i is None else X(i), 960 if p is None else Y(p)))
    keys.append((ev["end"] - 0.2, 0.4, 1.0, 540, 960))
    keys.sort(key=lambda k: k[0])
    s, cx, cy = keys[0][2], keys[0][3], keys[0][4]
    for t0, dur, s1, x1, y1 in keys:
        if t >= t0:
            k = eio((t - t0) / dur)
            s, cx, cy = s + (s1 - s) * k, cx + (x1 - cx) * k, cy + (y1 - cy) * k
    if t >= ev["ans"]: s += 0.05 * (1 - ease((t - ev["ans"]) / 0.35))
    return s, cx, cy

def headlines(ev):
    return [(T(e, ev), segs) for e, segs in S.HEAD]

def draw_track(d, t, ev, ea):
    TR = S.TRACK; n = len(TR["labels"]); w, gap, y0, h = 150, 26, 210, 150
    a0 = fade(t, T(TR.get("a", 0), ev), 0.3) * (1 - ea)
    if a0 <= 0: return
    x0 = W / 2 - (n * w + (n - 1) * gap) / 2
    allok = all(t >= T(e, ev) for e in TR["ev"])
    for k, (lab, e) in enumerate(zip(TR["labels"], TR["ev"])):
        x = x0 + k * (w + gap); te = T(e, ev); on = t >= te
        g = ease((t - te) / 0.3) if on else 0
        col = GREEN if allok else (GOLD if on else MUTED)
        bump = 1 + 0.12 * (1 - g) * (1 if on else 0)
        cx, cy = x + w / 2, y0 + h / 2
        ww, hh = w * bump, h * bump
        d.rounded_rectangle(sc([cx - ww / 2, cy - hh / 2, cx + ww / 2, cy + hh / 2]), radius=22 * SS,
                            fill=rgba(LABEL_BG, 0.95 * a0), outline=rgba(col if on else MUTED, a0 * (0.9 if on else 0.5)), width=int(3 * SS))
        d.text(sc((cx, cy - 22)), str(k + 1), font=font(POP_B, 54), fill=rgba(col if on else MUTED, a0), anchor="mm")
        if on: check(d, cx + ww / 2 - 26, cy - hh / 2 + 26, 10, col, a0 * g, 4)
        d.text(sc((cx, cy + 38)), lab, font=font(POP_B, 22), fill=rgba(INK if on else MUTED, a0), anchor="mm")
    tag = TR.get("tag")
    if tag: d.text(sc((W - 60, 110)), tag, font=font(POP_M, 24), fill=rgba(MUTED, a0), anchor="rm")

def draw_result(d, t, ev, ea):
    R = S.RESULT; ta = T(R["a"], ev)
    a = fade(t, ta, 0.2) * (1 - fade(t, T(R.get("b", "end"), ev) - 0.1, 0.3)) * (1 - ea)
    if a <= 0: return
    sz = int(230 * (1 + 0.3 * (1 - ease((t - ta) / 0.35))))
    d.text(sc((W / 2, 520)), R["text"], font=font(ANT, sz), fill=rgba(GREEN, a), anchor="mm",
           stroke_width=int(6 * SS), stroke_fill=rgba(BG, a))

def draw_ui(d, t, ev, chs, end_t):
    d.ellipse(sc([60, 92, 76, 108]), fill=GOLD)
    d.text(sc((88, 100)), "NiccoFX", font=font(POP_B, 30), fill=INK, anchor="lm")
    B.draw_head(d, t, ev)
    E = S.END
    ea = fade(t, ev["end"], 0.35)
    if getattr(S, "TRACK", None): draw_track(d, t, ev, ea)
    if getattr(S, "RESULT", None): draw_result(d, t, ev, ea)
    if ea > 0 and E.get("save"):
        d.rectangle(sc([0, 150, W, 1480]), fill=rgba(BG, 0.97 * ea))
        s1 = 1 + 0.25 * (1 - ease((t - ev["end"]) / 0.35))
        d.text(sc((W / 2, 470)), "COMMENT", font=font(ANT, 130), fill=rgba(INK, ea), anchor="mm")
        bx, by, bw, bh = W / 2, 690, 250 * s1, 150 * s1
        d.rounded_rectangle(sc([bx - bw, by - bh, bx + bw, by + bh]), radius=60 * SS, fill=rgba(GOLD, ea))
        d.polygon([sc((bx - 90, by + bh - 4)), sc((bx - 10, by + bh - 4)), sc((bx - 120, by + bh + 80))], fill=rgba(GOLD, ea))
        d.text(sc((bx, by + 4)), "SMA", font=font(ANT, int(190 * s1)), fill=rgba(BG, ea), anchor="mm")
        a2 = fade(t, ev["end"] + 0.35, 0.3)
        d.text(sc((W / 2, 965)), E.get("sub", "I'll DM you my free guide"), font=font(POP_B, 44), fill=rgba(INK, a2), anchor="mm")
        fb = font(POP_B, 48); tw = d.textlength("Follow NiccoFX", font=fb) / SS
        d.rounded_rectangle(sc([W / 2 - tw / 2 - 34, 1060, W / 2 + tw / 2 + 34, 1156]), radius=48 * SS, fill=rgba(GOLD, a2))
        d.text(sc((W / 2, 1108)), "Follow NiccoFX", font=fb, fill=rgba(BG, a2), anchor="mm")
    elif ea > 0:
        d.rectangle(sc([0, 150, W, 1480]), fill=rgba(BG, 0.97 * ea))
        f1 = font(POP_B, E.get("size", 76))
        d.text(sc((W / 2, 600)), E["l1"], font=f1, fill=rgba(E.get("c1", INK), ea), anchor="mm")
        d.text(sc((W / 2, 700)), E["l2"], font=f1, fill=rgba(E.get("c2", GOLD), ea), anchor="mm")
        a2 = fade(t, ev["end"] + 0.35, 0.3)
        fb = font(POP_B, 52)
        tw = d.textlength("Follow NiccoFX", font=fb) / SS
        d.rounded_rectangle(sc([W / 2 - tw / 2 - 34, 840, W / 2 + tw / 2 + 34, 940]), radius=50 * SS, fill=rgba(INK, a2))
        d.text(sc((W / 2, 890)), "Follow NiccoFX", font=fb, fill=rgba(BG, a2), anchor="mm")
        d.text(sc((W / 2, 1020)), E["sub"], font=font(POP_M, 34), fill=rgba(MUTED, a2), anchor="mm")
    else:
        B.draw_caption(d, t, chs, end_t)
    d.text(sc((W / 2, 1860)), "Education only · Not financial advice", font=font(POP_M, 22), fill=rgba(MUTED, 0.8), anchor="mm")

B.fix_words = fix_words; B.schedule = schedule; B.world = world; B.camera = camera
B.headlines = headlines; B.KEY = dict(getattr(S, "KEY", {}), niccofx=GOLD, decide=GOLD); B.draw_ui = draw_ui

def write_events(path):
    words = fix_words(json.load(open(sys.argv[1])))
    ev = schedule(words)
    quiz = "decide" in S.EV
    sfx = [["pop", 0.05]] + ([["pop", ev["n3"]], ["pop", ev["n2"]], ["pop", ev["n1"]], ["impact", ev["ans"]]] if quiz else [["impact", 0.05]])
    for (e, *_r) in S.CAM: sfx.append(["whoosh", T(e, ev)])
    cmp = getattr(S, "CMP", None)
    if cmp: sfx += [["whoosh", T(cmp["a"], ev) - 0.2], ["pop", T(cmp["cards"][1]["t"], ev)]]
    for kind, e in getattr(S, "SFX", []): sfx.append([kind, T(e, ev)])
    sfx.append(["whoosh", ev["end"] - 0.15])
    sfx = [[k, round(v, 2)] for k, v in sfx if (0.35 if k in ("whoosh", "riser") else 0) <= v < 900]
    end_t = words[-1][2] + 1.8
    out = {"sfx": sfx, "dur": round(end_t + 0.1, 2)}
    if quiz: out.update({"break": round(ev["decide"], 2), "resume": round(ev["ans"], 2)})
    json.dump(out, open(path, "w"))
    print("events", path, round(end_t, 2), "missing:", MISSING)

if __name__ == "__main__":
    if "--events" in sys.argv:
        write_events(sys.argv[sys.argv.index("--events") + 1])
    else:
        B.main()
        if MISSING: print("MISSING", MISSING)
