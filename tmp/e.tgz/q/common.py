from r8 import INK, GREEN, RED, GOLD, MUTED
CD = dict(decide="decide", n3="three|3", n2="two|2", n1=("one|1", 0), end="follow")
