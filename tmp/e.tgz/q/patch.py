import json, sys, re
P = {
 10: [("displayed,",0,"displacement."),("fly.",0,"flies."),("slow.",0,"slowly.")],
 11: [("side.",0,"size."),("one,",0,"160."),("six,",0,None),("two",0,"Two"),("losses.",0,"losses,"),("Minus",0,"minus"),
      ("two,",0,"200."),("1",0,"1,200."),(",200.",0,None),("loss.",0,"losses.")],
 12: [("break.",0,"breaks."),("struck.",0,"structure."),("continued.",0,"continues."),("what?",0,"watch."),("care.",0,"character."),("low.",0,"lows.")],
 14: [],
 15: [("79",0,"79%"),("%",0,None),("break,",0,"breakout,")],
 16: [("flipped.",0,"flips."),("trash.",0,"trapped."),("I'll",0,"Follow"),("owe",0,None)],
 17: [("low.",0,"lows."),("Why?",0,"Watch."),("Tarte.",0,"targets.")],
}
n = int(sys.argv[1]); f = sys.argv[2]
w = json.load(open(f))
for old, occ, new in P.get(n, []):
    k = 0
    for i, x in enumerate(w):
        if x[0] == old:
            if k == occ:
                if new is None:
                    w[i - 1][2] = x[2]; w.pop(i)
                else: x[0] = new
                break
            k += 1
    else: print("NOT FOUND", old)
json.dump(w, open(f, "w")); print(n, " ".join(x[0] for x in w)[:400])
